package com.readerpro.notes;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";
    private static final int REQ_FILE_CHOOSER = 101;
    private static final int REQ_SAVE_FILE = 102;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private byte[] pendingSaveBytes;

    // Page ke andar inject hone wali script:
    //  - window.print()  -> native print/Save as PDF
    //  - backup download -> native "Save file" dialog
    private static final String INJECT_JS =
            "(function(){try{"
            + "if(window.__nativeReady)return;window.__nativeReady=true;"
            + "window.print=function(){try{Android.printPage(document.title||'Notes');}catch(e){}};"
            + "if(window.NR&&NR.u){NR.u.download=function(name,text,type){"
            + "try{Android.saveFile(String(name),String(text),String(type||'application/json'));}catch(e){}};}"
            + "}catch(e){}})();";

    private static final String BACK_JS =
            "(function(){try{"
            + "if(NR.reader&&NR.reader.on){NR.reader.close();return 1;}"
            + "if(NR.modal&&NR.modal.closeTop())return 1;"
            + "var de=document.documentElement;"
            + "if(de.classList.contains('drawer')){de.classList.remove('drawer');return 1;}"
            + "if(NR.sel&&NR.sel.on){NR.sel.setMode(false);return 1;}"
            + "var h=location.hash.slice(1);"
            + "if(h&&h!=='notes'){location.hash='#notes';return 1;}"
            + "}catch(e){}return 0;})()";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.addJavascriptInterface(new Bridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(INJECT_JS, null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "फ़ाइल चुनें"), REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript(BACK_JS, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"1".equals(value)) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback == null) {
                return;
            }
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    result = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) {
                        result[i] = clip.getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }

        if (requestCode == REQ_SAVE_FILE) {
            byte[] bytes = pendingSaveBytes;
            pendingSaveBytes = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && bytes != null) {
                try {
                    OutputStream os = getContentResolver().openOutputStream(data.getData());
                    if (os != null) {
                        os.write(bytes);
                        os.close();
                        Toast.makeText(this, "फ़ाइल सेव हो गई ✓", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "फ़ाइल सेव नहीं हो पाई", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    /** JavaScript se bulaye jaane wale native functions. */
    private class Bridge {

        @JavascriptInterface
        public void saveFile(final String name, final String text, final String mime) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        pendingSaveBytes = text.getBytes(StandardCharsets.UTF_8);
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType(mime == null || mime.isEmpty() ? "application/json" : mime);
                        i.putExtra(Intent.EXTRA_TITLE, name);
                        startActivityForResult(i, REQ_SAVE_FILE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "फ़ाइल सेव नहीं हो पाई", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void printPage(final String title) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                        String job = (title == null || title.trim().isEmpty()) ? "Notes" : title.trim();
                        final PrintDocumentAdapter base = webView.createPrintDocumentAdapter(job);
                        PrintDocumentAdapter wrapped = new PrintDocumentAdapter() {
                            @Override
                            public void onStart() {
                                base.onStart();
                            }

                            @Override
                            public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                                 CancellationSignal cancellationSignal,
                                                 LayoutResultCallback callback, Bundle extras) {
                                base.onLayout(oldAttributes, newAttributes, cancellationSignal, callback, extras);
                            }

                            @Override
                            public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                                CancellationSignal cancellationSignal,
                                                WriteResultCallback callback) {
                                base.onWrite(pages, destination, cancellationSignal, callback);
                            }

                            @Override
                            public void onFinish() {
                                base.onFinish();
                                webView.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        webView.evaluateJavascript(
                                                "window.dispatchEvent(new Event('afterprint'))", null);
                                    }
                                });
                            }
                        };
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .build();
                        pm.print(job, wrapped, attrs);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "PDF नहीं बन पाई", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }
}
