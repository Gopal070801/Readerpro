/* Notes Reader — combined app script (util · config · storage+status · model · query · cards · actions · saved · reader · stats · modal · exporter · settings · app) */

/* ======== 00-util.js ======== */
/* util.js — chhote helper functions */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
  function cssEsc(s) { return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/["\\]/g, '\\$&'); }

  function hash(s) {
    var h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }
  function debounce(fn, ms) {
    var t;
    return function () {
      var a = arguments, c = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(c, a); }, ms);
    };
  }
  function fmt(n) { return Number(n).toLocaleString('en-IN'); }
  function pct(a, b) { return b ? Math.round((a / b) * 100) : 0; }

  // Topic/tag ke liye stable hue (0-359)
  function hue(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 360;
    return h;
  }

  var toastT;
  function toast(msg, ms) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('on');
    clearTimeout(toastT);
    toastT = setTimeout(function () { el.classList.remove('on'); }, ms || 2200);
  }

  function copy(text) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) {}
      ta.remove();
      return ok;
    }
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return fallback(); });
    }
    return Promise.resolve(fallback());
  }

  function download(name, text, type) {
    var url = URL.createObjectURL(new Blob([text], { type: type || 'application/json' }));
    var a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }

  NR.u = { $: $, $$: $$, esc: esc, cssEsc: cssEsc, hash: hash, debounce: debounce, fmt: fmt, pct: pct, hue: hue, toast: toast, copy: copy, download: download };
})(window.NR);

/* ======== 01-config.js ======== */
/* config.js — saari settings ek jagah. */
window.NR = window.NR || {};
NR.config = {
  appTitle: 'Notes Reader',
  dataGlobal: 'PYQ_SEED',
  storagePrefix: 'nr:v1:',

  // Performance: ek baar me kitne cards DOM me jode jayein
  firstBatch: 8, nextBatch: 8, liteBatch: 5, frameBudgetMs: 8,

  // Jin tags wale notes "analysis/pattern notes" hain (weightage me count nahi hote, insight ke kaam aate hain)
  metaTags: ['pattern'],

  tagLabels: {
    mts:     { label: 'MTS',            cls: 't-mts' },
    other:   { label: 'Other exams', cls: 't-other' },
    pattern: { label: 'Pattern note',      cls: 't-pattern' }
  },
  tagOrder: ['mts', 'other', 'pattern'],

  markers: [
    { emoji: '🧠', key: 'mnemonic', label: 'Mnemonic' },
    { emoji: '➕', key: 'extra',    label: 'Extra' },
    { emoji: '⚠️', key: 'warn',     label: 'Warning' },
    { emoji: '⚠',  key: 'warn',     label: 'Warning' },
    { emoji: '📌', key: 'pin',      label: 'Key point' }
  ],
  trapRegex: /^\**\s*(भ्रम|जाल)/,
  trapLabel: 'Traps',

  // Exam-source ka zikr (weightage ka anuman + "kis exam se zyada" insight)
  exams: [
    { label: 'MTS',            re: /\bMTS\b/g },
    { label: 'CHSL',           re: /\bCHSL\b/g },
    { label: 'CGL',            re: /\bCGL\b/g },
    { label: 'GD',             re: /\bGD\b/g },
    { label: 'CPO',            re: /\bCPO\b/g },
    { label: 'DP',             re: /\bDP\b/g },
    { label: 'Steno',          re: /\bSteno\b/g },
    { label: 'Selection Post', re: /\bSelection Post\b/g }
  ],

  // Pattern-notes me "kul N prashn – MTS a, anya b" jaisi line se asli PYQ-ginti nikalte hain
  declaredRe: /कुल\s*(\d+)\s*प्रश्न/,
  declaredMtsRe: /MTS\s*(\d+)/,
  declaredOthRe: /अन्य\s*(\d+)/,
  // Pattern-notes ki jin lines me dohraav ka zikr ho
  repeatLineRe: /दोहर|दो बार|तीन बार|बार-बार|एक ही तथ्य/,

  highlightColors: [
    { id: 1, name: 'Yellow' }, { id: 2, name: 'Green' }, { id: 3, name: 'Pink' }, { id: 4, name: 'Blue' }
  ],

  // Concept-analysis me ignore hone wale aam shabd (function-words + notes ke "meta" shabd)
  stopwords: ('का की के को में से है हैं था थे थी हो होता होती होते और या पर यह वह ये वे एक कि ही भी तो जो ने नहीं लिए द्वारा ' +
    'कुछ सभी इसे उस इस तथा अधिक बाद तक साथ बिना बीच वाले वाला वाली जाता जाती जाते करता करती करते कर रहता अथवा जब तब अन्य ' +
    'उदा सही गलत प्रश्न प्रश्नों विकल्प कथन दोनों केवल जैसे यानी अर्थात इसके उसके इनमें उनमें इसमें उसमें बनता बनती बनते जाना ' +
    'इसलिए हेतु इसी उसी जिन जिनमें लेकिन सिर्फ़ सिर्फ ज़्यादा ज्यादा होने होगा होगी जाए जाने देता देती देते लेता मिलता मिलती मिलते ' +
    'कहलाता कहते कहा माना मानी चाहिए चाहिये वही वहीं यहीं जैसा ऐसा ऐसे इन उन इनका उनका इनके अपने अपना खास पहली पहला दूसरा दूसरी तीसरा ' +
    'दौरान कारण अंतर तुलना दिया दी लिया ली हुआ हुई हुए रहे रही रहा सकता सकती सकते अगर यदि निकले आदि इत्यादि तरह एवं ओर लिये ऊपर नीचे अंदर बाहर ' +
    'तथ्य पूछा पूछे पूछ आए आया आती आते गया गई गए करना किया किसी कोई उनके जिसमें जिस जिसे रूप बने बना बनी बनाता लगभग प्रायः अक्सर ' +
    'कम बहुत सबसे पहले दो तीन चार पाँच छह नाम दोहराव दोहराए पक्का याद रट्टा पढ़ें पढ़ना जोड़ी जोड़ियाँ सूची सूचियाँ परिभाषा ' +
    'भ्रम जाल सूत्र अतिरिक्त परीक्षा परीक्षाएँ पैटर्न ट्रेंड उपयोग उत्तर मुख्य उदाहरण प्रकार क्रम अलग भारत क्षेत्र बढ़ने करने स्रोत ' +
    'गुण उच्च हेतु नीचे वाले आधार मतलब कहलाती कहलाते इसका इसकी इनमें साथ-साथ ' +
    'MTS CHSL CGL GD CPO DP Steno Selection Post Phase Nov Oct Dec Jan Feb Mar Apr May Jun Jul Aug Sep S1 S2 S3 Q the of in is and Constable AWO TPO HCM ' +
    'होकर शब्द बनाने देखें करके पाया पाई जाता हल्की वृद्धि तेज़ मिलाकर रखें रखना बनाना Matter Phase').split(/\s+/),
  // Bold shabd jo concept nahi hain
  genericTerms: ['याद-सूत्र', 'अतिरिक्त', 'भ्रम/जाल', 'भ्रम', 'जाल', 'पैटर्न', 'गिनती', 'उपयोग', 'सीमा', 'MTS के लिए पक्का करें', 'MTS के लिए पक्का']
};

/* ======== 01b-scheduler.js ======== */
/* scheduler.js — bhaari kaam ko chhote tukdon me todta hai taaki page kabhi freeze/lag na ho (2GB RAM / slow CPU ke liye) */
window.NR = window.NR || {};
(function (NR) {
  'use strict';

  // Agla frame; hidden tab me rAF ruk jaata hai, isliye timeout fallback
  function frame() {
    return new Promise(function (res) {
      var done = false;
      function go() { if (!done) { done = true; res(); } }
      requestAnimationFrame(go);
      setTimeout(go, 60);
    });
  }

  // arr ke har item par fn(item, index) chalata hai; har frame me sirf `budget` ms kaam
  async function chunk(arr, fn, opts) {
    opts = opts || {};
    var budget = opts.budget || NR.config.frameBudgetMs;
    var n = arr.length, i = 0;
    while (i < n) {
      var t0 = performance.now();
      do { fn(arr[i], i); i++; } while (i < n && performance.now() - t0 < budget);
      if (opts.onProgress) opts.onProgress(i, n);
      if (i < n) await frame();
    }
  }

  NR.sched = { frame: frame, chunk: chunk };
})(window.NR);

/* ======== 02-storage.js ======== */
/* storage.js — preferences + highlights/saves + padhai-status (read / revised / star). localStorage, debounced. */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var PFX = NR.config.storagePrefix, SEP = '§';
  var persistent = true;

  function read(k, def) {
    try { var v = localStorage.getItem(PFX + k); return v ? JSON.parse(v) : def; }
    catch (e) { persistent = false; return def; }
  }
  function write(k, v) {
    try { localStorage.setItem(PFX + k, JSON.stringify(v)); return true; }
    catch (e) { persistent = false; return false; }
  }

  /* ---------- Preferences ---------- */
  var DEF = { theme: 'auto', fs: 17, lh: 1.65, font: 'sans', density: 'cozy', lite: null,
              view: 'grid', sort: 'orig', dir: 'asc', fold: false, savedSort: 'auto',
              wmetric: 'q', autoRead: true, goal: 5, fx: true, bstyle: 'marker', hstyle: 'soft', bcol: 'auto' };
  var pdata = Object.assign({}, DEF, read('prefs', {}));
  var plisteners = [];
  var saveP = NR.u.debounce(function () { write('prefs', pdata); }, 300);

  NR.prefs = {
    get: function (k) { return pdata[k]; },
    set: function (k, v) { pdata[k] = v; saveP(); plisteners.forEach(function (f) { f(k, v); }); },
    all: function () { return pdata; },
    on: function (f) { plisteners.push(f); },
    reset: function () { pdata = Object.assign({}, DEF); saveP(); }
  };

  /* ---------- Marks: highlight (c = 1..4) aur save (v = 1) ---------- */
  var marks = new Map();
  var raw = read('marks', null);
  if (raw && raw.m) Object.keys(raw.m).forEach(function (id) { marks.set(id, raw.m[id]); });

  var mlisteners = [];
  var saveM = NR.u.debounce(flushM, 350);
  function flushM() {
    var o = {};
    marks.forEach(function (m, id) { o[id] = m; });
    write('marks', { v: 1, m: o });
  }

  /* ---------- Status: note-level read (r) / revised (d) / star (s) ---------- */
  var smap = new Map(), slisteners = [];
  var rawS = read('status', null);
  if (rawS && rawS.m) Object.keys(rawS.m).forEach(function (k) {
    var a = rawS.m[k]; smap.set(k, { r: a[0] | 0, d: a[1] | 0, s: a[2] | 0, t: a[3] || 0 });
  });
  var saveS = NR.u.debounce(flushS, 350);
  function flushS() {
    var o = {};
    smap.forEach(function (m, k) { o[k] = [m.r, m.d, m.s, m.t]; });
    write('status', { v: 1, m: o });
  }
  function flushAll() { flushM(); flushS(); }
  window.addEventListener('pagehide', flushAll);
  document.addEventListener('visibilitychange', function () { if (document.hidden) flushAll(); });

  function sCommit(key, m) {
    if (!m.r && !m.d && !m.s) smap.delete(key); else smap.set(key, m);
    saveS(); slisteners.forEach(function (f) { f(key); });
  }
  NR.status = {
    get: function (key) { return smap.get(key) || null; },
    flag: function (key, f) { var m = smap.get(key); return m ? m[f] | 0 : 0; },
    set: function (key, f, v) {
      var m = smap.get(key) || { r: 0, d: 0, s: 0, t: 0 };
      m = { r: m.r, d: m.d, s: m.s, t: Date.now() };
      m[f] = v ? 1 : 0;
      if (f === 'd' && v) m.r = 1;      // revised => read bhi
      if (f === 'r' && !v) m.d = 0;     // unread => revised bhi hat
      sCommit(key, m); return m[f];
    },
    toggle: function (key, f) { return NR.status.set(key, f, !NR.status.flag(key, f)); },
    clear: function () { var ks = Array.from(smap.keys()); smap.clear(); saveS(); ks.forEach(function (k) { slisteners.forEach(function (f) { f(k); }); }); },
    on: function (f) { slisteners.push(f); },
    // notes list par counts: {read, todo (padha par revise baaki), rev, star, unread}
    counts: function (notes) {
      var c = { n: notes.length, read: 0, todo: 0, rev: 0, star: 0, unread: 0 };
      for (var i = 0; i < notes.length; i++) {
        var m = smap.get(notes[i].key);
        if (!m || !m.r) { c.unread++; } else { c.read++; if (m.d) c.rev++; else c.todo++; }
        if (m && m.s) c.star++;
      }
      return c;
    }
  };

  function emit(id) { mlisteners.forEach(function (f) { f(id); }); }
  function touch(id, meta) {
    var m = marks.get(id);
    if (!m) { m = { c: 0, v: 0, t: Date.now() }; if (meta) { if (meta.h) m.h = meta.h; if (meta.s) m.s = meta.s.slice(0, 400); } }
    return m;
  }
  function commit(id, m) {
    if (!m.c && !m.v) marks.delete(id); else marks.set(id, m);
    saveM(); emit(id);
  }

  NR.store = {
    SEP: SEP,
    marks: marks,
    get persistent() { return persistent; },
    cid: function (key) { return 'c' + SEP + key; },
    pid: function (key, i) { return 'p' + SEP + key + SEP + i; },
    parse: function (id) {
      var a = id.split(SEP);
      return { t: a[0], key: a[1], i: a[0] === 'p' ? +a[2] : -1 };
    },
    get: function (id) { return marks.get(id); },
    setColor: function (id, c, meta) { var m = touch(id, meta); m.c = (m.c === c) ? 0 : c; commit(id, m); return m.c; },
    toggleSave: function (id, meta) { var m = touch(id, meta); m.v = m.v ? 0 : 1; commit(id, m); return m.v; },
    remove: function (id) { if (marks.has(id)) { marks.delete(id); saveM(); emit(id); } },
    clearAll: function () { var ids = Array.from(marks.keys()); marks.clear(); saveM(); ids.forEach(emit); },
    on: function (f) { mlisteners.push(f); },
    counts: function () {
      var r = { total: marks.size, saved: 0, hl: 0, cards: 0, points: 0, byColor: [0, 0, 0, 0, 0] };
      marks.forEach(function (m, id) {
        if (m.v) r.saved++;
        if (m.c) { r.hl++; r.byColor[m.c]++; }
        if (id.charAt(0) === 'c') r.cards++; else r.points++;
      });
      return r;
    },
    reconcile: function (byKey) {
      var moves = [];
      marks.forEach(function (m, id) {
        if (id.charAt(0) !== 'p') return;
        var p = NR.store.parse(id), n = byKey.get(p.key);
        if (!n || !m.h) return;
        var ln = n.lines[p.i];
        if (ln && ln.h === m.h) return;
        for (var j = 0; j < n.lines.length; j++) {
          if (n.lines[j].h === m.h) { moves.push([id, NR.store.pid(p.key, j), m]); break; }
        }
      });
      moves.forEach(function (mv) { marks.delete(mv[0]); marks.set(mv[1], mv[2]); });
      if (moves.length) saveM();
    },
    exportJSON: function () {
      var o = {}, s = {};
      marks.forEach(function (m, id) { o[id] = m; });
      smap.forEach(function (m, k) { s[k] = [m.r, m.d, m.s, m.t]; });
      return JSON.stringify({ app: 'notes-reader', v: 2, exported: new Date().toISOString(), marks: o, status: s, prefs: pdata, game: NR.game ? NR.game.dump() : null }, null, 1);
    },
    importJSON: function (text) {
      var d = JSON.parse(text);
      if (!d || (!d.marks && !d.status)) throw new Error('Invalid file');
      var n = 0;
      Object.keys(d.marks || {}).forEach(function (id) {
        var m = d.marks[id];
        if (m && (m.c || m.v)) { marks.set(id, { c: m.c | 0, v: m.v | 0, t: m.t || Date.now(), h: m.h, s: m.s }); n++; }
      });
      Object.keys(d.status || {}).forEach(function (k) {
        var a = d.status[k];
        if (a && (a[0] || a[1] || a[2])) { smap.set(k, { r: a[0] | 0, d: a[1] | 0, s: a[2] | 0, t: a[3] || 0 }); n++; }
      });
      if (d.game && NR.game) { try { NR.game.load(d.game); } catch (e) {} }
      saveM(); saveS(); mlisteners.forEach(function (f) { f(null); }); slisteners.forEach(function (f) { f(null); });
      return n;
    }
  };
})(window.NR);

/* ======== 03-markdown.js ======== */
/* markdown.js — data ke "- **bold**" style text ko safe HTML me badalta hai */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var esc = NR.u.esc, hash = NR.u.hash, C = NR.config;

  function kindOf(t) {
    var s = t.replace(/^[\s*]+/, '');
    for (var i = 0; i < C.markers.length; i++) {
      if (s.indexOf(C.markers[i].emoji) === 0) return C.markers[i].key;
    }
    if (C.trapRegex.test(t)) return 'trap';
    return '';
  }

  // **bold** (colour+bold), *italic* aur `code` — pehle escape, phir tags (XSS-safe)
  // ***x*** (bold+italic), **x** (andar *italic* ho sakta hai), *x*, `x` — sab nested/adjacent case sambhalta hai
  function inline(t) {
    return esc(t)
      .replace(/\*\*\*(?=\S)([^*]+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*(?=\S)((?:[^*]|\*(?!\*))+?)\*\*(?!\*)/g, '<strong>$1</strong>')
      .replace(/\*([^\s*](?:[^*]*?[^\s*])?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+?)`/g, '<code>$1</code>');
  }

  // 'a' string -> [{t, l (level), k (kind), h (hash), p (plain para?)}]
  function parse(a) {
    var out = [], lines = String(a || '').split('\n');
    for (var i = 0; i < lines.length; i++) {
      var raw = lines[i];
      if (!raw.trim()) continue;
      var m = /^(\s*)[-*•]\s+(.*)$/.exec(raw), text, lvl = 0, plain = 0;
      if (m) { lvl = m[1].length >= 2 ? 1 : 0; text = m[2]; }
      else { text = raw.trim(); plain = 1; }
      out.push({ t: text, l: lvl, k: kindOf(text), h: hash(text), p: plain });
    }
    return out;
  }

  function strip(t) { return t.replace(/\*\*/g, '').replace(/\*([^\s*](?:[^*]*?[^\s*])?)\*/g, '$1').replace(/`/g, ''); }

  // Search-term ko <mark> se ghero (sirf text nodes me, tags ke andar nahi)
  function termsRe(terms) {
    if (!terms || !terms.length) return null;
    var parts = terms.map(function (t) { return t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); });
    try { return new RegExp('(' + parts.join('|') + ')', 'giu'); } catch (e) { return null; }
  }
  function mark(html, re) {
    if (!re) return html;
    return html.replace(/(<[^>]+>)|([^<]+)/g, function (m, tag, txt) {
      return tag ? tag : txt.replace(re, '<mark>$1</mark>');
    });
  }

  NR.md = { parse: parse, inline: inline, strip: strip, kindOf: kindOf, termsRe: termsRe, mark: mark };
})(window.NR);

/* ======== 04-model.js ======== */
/* model.js — data-file (PYQ_SEED) ko normalize karke memory-efficient notes list banata hai (chunks me). */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var C = NR.config, md = NR.md;

  var M = { notes: [], byKey: new Map(), topics: new Map(), tags: new Map(), subjects: new Map(), version: 0 };

  function examCounts(text) {
    var o = null, tot = 0;
    for (var i = 0; i < C.exams.length; i++) {
      var m = text.match(C.exams[i].re);
      if (m) { o = o || {}; o[C.exams[i].label] = m.length; tot += m.length; }
    }
    return { ex: o, tot: tot };
  }

  function normalize(r, order) {
    var subj = String(r.subj || 'General');
    var sid = String(r.sid != null ? r.sid : 'n' + order);
    var topic = String(r.topic || 'General');
    var title = String(r.q || '(Untitled)');
    var lines = md.parse(r.a);
    var plain = [], pts = 0, mk = {}, body = '';
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i], p = md.strip(ln.t);
      plain.push(p); body += p + '\n';
      if (!ln.p) pts++;
      if (ln.k) mk[ln.k] = (mk[ln.k] || 0) + 1;
    }
    var tags = Array.isArray(r.tags) ? r.tags.map(function (t) { return String(t).toLowerCase(); }) : [];
    var meta = tags.some(function (t) { return C.metaTags.indexOf(t) >= 0; });
    // pattern-note me likhi hui asli PYQ ginti ("कुल 41 प्रश्न – MTS 17, अन्य 24")
    var decl = null;
    if (meta) {
      for (var j = 0; j < plain.length; j++) {
        var q = C.declaredRe.exec(plain[j]);
        if (q) {
          var a = C.declaredMtsRe.exec(plain[j]), b = C.declaredOthRe.exec(plain[j]);
          decl = { q: +q[1], mts: a ? +a[1] : 0, oth: b ? +b[1] : 0 };
          break;
        }
      }
    }
    var ec = meta ? { ex: null, tot: 0 } : examCounts(body);
    var tt = title.replace(/^[^|]{0,40}\|\s*/, '');
    return {
      key: subj + '/' + sid, sid: sid, subj: subj, topic: topic, tk: subj + '\u0001' + topic,
      title: title, sortTitle: tt.toLowerCase(), tags: tags, lines: lines, meta: meta, decl: decl,
      ex: ec.ex, exTotal: ec.tot,
      pts: pts || lines.length, mk: mk, order: order, topicOrder: 0,
      search: (topic + ' ' + title + ' ' + plain.join(' ')).toLowerCase()
    };
  }

  M.ingest = async function (arr, onProgress) {
    arr = arr || window[C.dataGlobal] || [];
    var fresh = arr.filter(function (r) {
      return r && r.q != null && r.a != null && !M.byKey.has(String(r.subj || 'General') + '/' + String(r.sid));
    });
    var added = 0;
    await NR.sched.chunk(fresh, function (r) {
      var n = normalize(r, M.notes.length);
      if (M.byKey.has(n.key)) return;
      var t = M.topics.get(n.tk);
      if (!t) { t = { key: n.tk, name: n.topic, subj: n.subj, order: M.topics.size, count: 0 }; M.topics.set(n.tk, t); }
      t.count++;
      n.topicOrder = t.order;
      n.tags.forEach(function (g) { M.tags.set(g, (M.tags.get(g) || 0) + 1); });
      M.subjects.set(n.subj, (M.subjects.get(n.subj) || 0) + 1);
      M.byKey.set(n.key, n);
      M.notes.push(n);
      added++;
    }, { onProgress: onProgress });
    if (added) { M.version++; NR.store.reconcile(M.byKey); }
    return added;
  };

  NR.model = M;
})(window.NR);

/* ======== 05-query.js ======== */
/* query.js — filters + sorting (search, status, tag, topic, subject) */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var C = NR.config;
  var coll = (typeof Intl !== 'undefined' && Intl.Collator) ? new Intl.Collator(['hi', 'en'], { numeric: true, sensitivity: 'base' }) : { compare: function (a, b) { return a < b ? -1 : a > b ? 1 : 0; } };

  function tagRank(n) {
    var best = 99;
    for (var i = 0; i < n.tags.length; i++) {
      var r = C.tagOrder.indexOf(n.tags[i]);
      if (r < 0) r = 50;
      if (r < best) best = r;
    }
    return best;
  }
  function stRank(n) { var m = NR.status.get(n.key); return !m || !m.r ? 0 : m.d ? 2 : 1; }
  function memo(n) { return (n.mk.mnemonic || 0) + (n.mk.trap || 0) + (n.mk.warn || 0); }

  var SORTS = {
    orig:    { label: 'Original order', def: 'asc', cmp: function (a, b) { return a.order - b.order; } },
    topic:   { label: 'Topic-wise (syllabus order)', def: 'asc', group: true, cmp: function (a, b) { return a.topicOrder - b.topicOrder; } },
    topicaz: { label: 'Topic-wise (A → Z)', def: 'asc', group: true, cmp: function (a, b) { return coll.compare(a.topic, b.topic); } },
    unread:  { label: 'Unread first', def: 'asc', cmp: function (a, b) { return stRank(a) - stRank(b); } },
    star:    { label: '★ Starred first', def: 'desc', cmp: function (a, b) { return NR.status.flag(a.key, 's') - NR.status.flag(b.key, 's'); } },
    title:   { label: 'Title (A → Z)', def: 'asc', cmp: function (a, b) { return coll.compare(a.sortTitle, b.sortTitle); } },
    pts:     { label: 'Number of points', def: 'desc', cmp: function (a, b) { return a.pts - b.pts; } },
    memo:    { label: 'Most mnemonics / traps', def: 'desc', cmp: function (a, b) { return memo(a) - memo(b); } },
    exam:    { label: 'MTS → Other → Pattern', def: 'asc', cmp: function (a, b) { return tagRank(a) - tagRank(b); } },
    mine:    { label: 'Most highlights / saves', def: 'desc', needsMarks: true }
  };

  var F = { q: '', tags: new Set(), topics: new Set(), subj: new Set(), status: '' };

  function marksPerNote() {
    var m = new Map();
    NR.store.marks.forEach(function (v, id) { var k = NR.store.parse(id).key; m.set(k, (m.get(k) || 0) + 1); });
    return m;
  }
  function terms() { return F.q.toLowerCase().split(/\s+/).filter(Boolean); }

  function statusOk(n, st) {
    var m = NR.status.get(n.key), r = m ? m.r : 0, d = m ? m.d : 0, s = m ? m.s : 0;
    if (st === 'unread') return !r;
    if (st === 'todo') return !!(r && !d);
    if (st === 'rev') return !!d;
    if (st === 'star') return !!s;
    return true;
  }

  function run() {
    var sortKey = NR.prefs.get('sort');
    if (!SORTS[sortKey]) sortKey = 'orig';
    var S = SORTS[sortKey], dir = NR.prefs.get('dir') === 'desc' ? -1 : 1;
    var ts = terms(), hasT = F.tags.size, hasP = F.topics.size, hasS = F.subj.size, st = F.status;

    var out = NR.model.notes.filter(function (n) {
      if (hasS && !F.subj.has(n.subj)) return false;
      if (hasP && !F.topics.has(n.tk)) return false;
      if (hasT) {
        var ok = false;
        for (var i = 0; i < n.tags.length; i++) if (F.tags.has(n.tags[i])) { ok = true; break; }
        if (!ok) return false;
      }
      if (st && !statusOk(n, st)) return false;
      for (var j = 0; j < ts.length; j++) if (n.search.indexOf(ts[j]) < 0) return false;
      return true;
    });

    var cmp = S.cmp;
    if (S.needsMarks) {
      var mm = marksPerNote();
      cmp = function (a, b) { return (mm.get(a.key) || 0) - (mm.get(b.key) || 0); };
    }
    if (sortKey !== 'orig' || dir < 0) out.sort(function (a, b) { return (cmp(a, b) * dir) || (a.order - b.order); });
    return { list: out, group: !!S.group, terms: ts, re: NR.md.termsRe(ts) };
  }

  function isFiltered() { return !!(F.q || F.tags.size || F.topics.size || F.subj.size || F.status); }
  function reset() { F.q = ''; F.tags.clear(); F.topics.clear(); F.subj.clear(); F.status = ''; }

  NR.query = { F: F, SORTS: SORTS, run: run, isFiltered: isFiltered, reset: reset, coll: coll, terms: terms };
})(window.NR);

/* ======== 06-cards.js ======== */
/* cards.js — card/bullet HTML + incremental list (thoda-thoda DOM me jodna, lag-free) */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, esc = u.esc, md = NR.md, store = NR.store, C = NR.config;

  function ic(name, cls) { return '<svg class="i' + (cls ? ' ' + cls : '') + '" aria-hidden="true"><use href="#i-' + name + '"/></svg>'; }

  function topicChip(n) { return '<span class="chip topic" style="--h:' + u.hue(n.topic) + '">' + esc(n.topic) + '</span>'; }
  function tagChips(n) {
    var s = '';
    for (var i = 0; i < n.tags.length; i++) {
      var t = n.tags[i], d = C.tagLabels[t] || { label: t, cls: 't-x' };
      s += '<span class="tag ' + d.cls + '">' + esc(d.label) + '</span>';
    }
    return s;
  }
  function sel(id) { return NR.sel && NR.sel.has(id); }

  function li(n, ln, i, re) {
    var m = store.get(store.pid(n.key, i)), c = [];
    if (ln.k) c.push('k-' + ln.k);
    if (ln.l) c.push('l2');
    if (ln.p) c.push('np');
    if (m) { if (m.c) c.push('hl' + m.c); if (m.v) c.push('sv'); }
    if (sel(store.pid(n.key, i))) c.push('picked');
    return '<li' + (c.length ? ' class="' + c.join(' ') + '"' : '') + ' data-i="' + i + '" tabindex="0">' + md.mark(md.inline(ln.t), re) + '</li>';
  }

  function stClass(n) {
    var s = NR.status.get(n.key), c = '';
    if (s) { if (s.r) c += ' is-read'; if (s.d) c += ' is-rev'; if (s.s) c += ' is-star'; }
    return c;
  }
  function fbtn(act, icon, label, cls) {
    return '<button class="fb ' + (cls || '') + '" data-act="' + act + '" aria-label="' + label + '">' + ic(icon) + '<span>' + label + '</span></button>';
  }

  /* ---- poora note-card ---- */
  function note(n, o) {
    o = o || {};
    var cid = store.cid(n.key), m = store.get(cid), cls = 'card';
    if (m && m.c) cls += ' hl' + m.c;
    if (m && m.v) cls += ' sv';
    if (o.folded) cls += ' folded';
    if (n.meta) cls += ' meta';
    if (sel(cid)) cls += ' picked';
    cls += stClass(n);
    var lis = '';
    for (var i = 0; i < n.lines.length; i++) lis += li(n, n.lines[i], i, o.re);
    return '<article class="' + cls + '" data-t="c" data-k="' + esc(n.key) + '" style="--h:' + u.hue(n.topic) + ';--i:' + Math.min(o.i || 0, 6) + '">' +
      '<header class="card-h"><span class="sel" aria-hidden="true"></span>' +
      '<div class="card-m">' + topicChip(n) + tagChips(n) + '<span class="stb"></span></div>' +
      '<div class="card-btns">' +
      '<button class="ib sm star-b" data-act="st-star" aria-label="Important (star)">' + ic('star') + '</button>' +
      '<button class="ib sm fold-b" data-act="fold" aria-label="Expand / collapse">' + ic('chev') + '</button></div>' +
      '<h3 class="card-t">' + md.mark(md.inline(n.title), o.re) + '</h3></header>' +
      '<div class="card-b"><div class="card-bi"><ul class="pts">' + lis + '</ul>' +
      '<footer class="card-f">' +
      fbtn('st-read', 'check', 'Read', 'rd-b') + fbtn('st-rev', 'repeat', 'Revise', 'rv-b') +
      fbtn('card-tools', 'pen', 'Highlight') + fbtn('card-save', 'bookmark', 'Save', 'sv-b') + fbtn('open-reader', 'book', 'Reader') +
      '</footer></div></div></article>';
  }

  /* ---- Reader mode ka note (ek hi, bada text) ---- */
  function reader(n) {
    var lis = '';
    for (var i = 0; i < n.lines.length; i++) lis += li(n, n.lines[i], i, null);
    var cid = store.cid(n.key), m = store.get(cid), cls = 'card rd-card' + (n.meta ? ' meta' : '');
    if (m && m.c) cls += ' hl' + m.c;
    return '<article class="' + cls + '" data-t="c" data-k="' + esc(n.key) + '" style="--h:' + u.hue(n.topic) + '">' +
      '<div class="rd-meta">' + topicChip(n) + tagChips(n) + '</div>' +
      '<h2 class="rd-t">' + md.inline(n.title) + '</h2><ul class="pts">' + lis + '</ul></article>';
  }

  /* ---- Save किया हुआ अकेला bullet ---- */
  function point(e, o) {
    o = o || {};
    var n = e.note, id = e.id, m = e.m, i = e.i;
    var orphan = !n || !n.lines[i], body;
    if (orphan) {
      var c = ['orphan'];
      if (m.c) c.push('hl' + m.c);
      if (m.v) c.push('sv');
      body = '<li class="' + c.join(' ') + '" data-id="' + esc(id) + '" data-i="' + i + '" tabindex="0">' + md.inline(m.s || '(content unavailable)') + '</li>';
    } else body = li(n, n.lines[i], i, o.re);
    var head = n
      ? topicChip(n) + '<a href="#notes" class="src" data-act="goto" data-k="' + esc(n.key) + '" data-i="' + i + '">' + md.inline(n.title) + ' ' + ic('out') + '</a>'
      : '<span class="chip">Source data file not loaded</span>';
    return '<article class="card pc" data-t="p" data-k="' + esc(e.key) + '" style="--h:' + (n ? u.hue(n.topic) : 220) + ';--i:' + Math.min(o.i || 0, 6) + '">' +
      '<header class="card-h"><div class="card-m src-row">' + head + '</div>' +
      '<div class="card-btns"><button class="ib sm" data-act="pt-tools" aria-label="Choose highlight colour">' + ic('pen') + '</button></div></header>' +
      '<ul class="pts">' + body + '</ul></article>';
  }

  function group(name, count, unit, extra) {
    return '<div class="grp" role="heading" aria-level="2"><span class="grp-t"' + (extra ? ' style="--h:' + u.hue(name) + '"' : '') + '>' + esc(name) +
      '</span><span class="grp-n">' + count + ' ' + unit + '</span></div>';
  }

  /* ---- Incremental list ---- */
  function IncList(root, sentinel) {
    var self = this;
    this.root = root; this.s = sentinel; this.rows = []; this.i = 0; this.build = null;
    this.io = new IntersectionObserver(function (es) {
      for (var k = 0; k < es.length; k++) if (es[k].isIntersecting) { self.more(); break; }
    }, { rootMargin: '1200px 0px' });
    this.io.observe(sentinel);
  }
  IncList.prototype.batch = function (first) {
    var lite = document.documentElement.classList.contains('lite');
    return lite ? C.liteBatch : (first ? C.firstBatch : C.nextBatch);
  };
  IncList.prototype.set = function (rows, build) {
    if (NR.actions) NR.actions.hide();
    this.rows = rows; this.build = build; this.i = 0;
    this.root.replaceChildren();
    this.s.hidden = false;
    this.more(true);
  };
  IncList.prototype.more = function (first, count) {
    var self = this;
    if (this.i >= this.rows.length) { this.s.hidden = true; return; }
    var end = Math.min(this.rows.length, this.i + (count || this.batch(first))), html = [];
    for (var j = this.i, k = 0; j < end; j++, k++) html.push(this.build(this.rows[j], k));
    this.i = end;
    this.root.insertAdjacentHTML('beforeend', html.join(''));
    if (this.i >= this.rows.length) { this.s.hidden = true; return; }
    this.io.unobserve(this.s);
    requestAnimationFrame(function () { self.io.observe(self.s); });
  };
  IncList.prototype.reveal = function (pred) {
    var idx = -1;
    for (var j = 0; j < this.rows.length; j++) if (pred(this.rows[j])) { idx = j; break; }
    if (idx < 0) return false;
    if (idx >= this.i) this.more(false, idx + 1 - this.i + 2);
    return true;
  };

  NR.cards = { note: note, reader: reader, point: point, group: group, ic: ic, topicChip: topicChip, tagChips: tagChips, li: li };
  NR.IncList = IncList;
})(window.NR);

/* ======== 07-actions.js ======== */
/* actions.js — bullet/card par highlight, save, copy, select. Ek hi shared floating toolbar (kam DOM = kam RAM). */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, store = NR.store, md = NR.md;
  NR.act = NR.act || {};

  /* ---------- Selection (PDF export ke liye) ---------- */
  var S = new Set(), selOn = false, lis = [];
  NR.sel = {
    get on() { return selOn; },
    get size() { return S.size; },
    has: function (id) { return S.has(id); },
    ids: function () { return Array.from(S); },
    onChange: function (f) { lis.push(f); },
    toggle: function (id) {
      if (S.has(id)) S.delete(id); else S.add(id);
      paint(id); fire(); return S.has(id);
    },
    add: function (ids) { ids.forEach(function (id) { S.add(id); }); paintAll(); fire(); },
    clear: function () { S.clear(); paintAll(); fire(); },
    setMode: function (on) {
      selOn = !!on;
      document.documentElement.classList.toggle('selecting', selOn);
      if (selOn) hide();
      var b = $('#btnSelect'); if (b) b.setAttribute('aria-pressed', selOn);
      fire();
    }
  };
  function fire() { lis.forEach(function (f) { f(); }); }
  function elFor(id) {
    var p = store.parse(id), out = [];
    u.$$('.card[data-k="' + u.cssEsc(p.key) + '"]').forEach(function (card) {
      if (p.t === 'c') { if (card.dataset.t === 'c') out.push(card); }
      else { var l = card.querySelector('li[data-i="' + p.i + '"]'); if (l) out.push(l); }
    });
    return out;
  }
  function paint(id) { elFor(id).forEach(function (e) { e.classList.toggle('picked', S.has(id)); }); }
  function paintAll() {
    u.$$('.card.picked, .pts li.picked').forEach(function (e) { e.classList.remove('picked'); });
    S.forEach(paint);
  }

  /* ---------- Id/meta helpers ---------- */
  function cardOf(el) { return el.closest('.card'); }
  function idOf(el) {
    if (el.tagName === 'LI') return el.dataset.id || store.pid(cardOf(el).dataset.k, el.dataset.i);
    var c = el.classList.contains('card') ? el : cardOf(el);
    return store.cid(c.dataset.k);
  }
  function metaOf(el) {
    var card = el.classList.contains('card') ? el : cardOf(el);
    var n = NR.model.byKey.get(card.dataset.k);
    if (!n) return null;
    if (el.tagName === 'LI') { var ln = n.lines[el.dataset.i]; return ln ? { h: ln.h, s: ln.t } : null; }
    return { s: n.title };
  }
  function textOf(el) {
    if (el.tagName === 'LI') return md.strip(el.textContent);
    var n = NR.model.byKey.get(el.dataset.k);
    return n ? md.strip(n.title) + '\n' + n.lines.map(function (l) { return '• ' + md.strip(l.t); }).join('\n') : '';
  }

  /* ---------- Floating toolbar ---------- */
  var fbar = $('#fbar');
  function target() {
    var h = fbar.parentNode;
    if (!h || h === document.body) return null;
    return h.tagName === 'LI' ? h : cardOf(h);
  }
  function sync() {
    var t = target(); if (!t) return;
    var m = store.get(idOf(t)) || {};
    u.$$('[data-c]', fbar).forEach(function (b) { b.setAttribute('aria-pressed', String(+b.dataset.c === (m.c || 0) && +b.dataset.c !== 0)); });
    var sb = $('[data-a="save"]', fbar); sb.classList.toggle('on', !!m.v);
  }
  function show(host) {
    if (fbar.parentNode === host && fbar.classList.contains('on')) { hide(); return; }
    host.appendChild(fbar);
    fbar.classList.remove('on'); void fbar.offsetWidth; fbar.classList.add('on');
    sync();
  }
  function hide() {
    fbar.classList.remove('on');
    if (fbar.parentNode !== document.body) document.body.appendChild(fbar);
  }
  NR.actions = { hide: hide };

  fbar.addEventListener('click', function (e) {
    e.stopPropagation();
    var b = e.target.closest('button'), t = target();
    if (!b || !t) return;
    var id = idOf(t), meta = metaOf(t);
    if (b.dataset.c !== undefined) {
      var c = +b.dataset.c, m = store.get(id);
      if (c === 0) { if (m && m.c) store.setColor(id, m.c, meta); }
      else store.setColor(id, c, meta);
    } else if (b.dataset.a === 'save') {
      var v = store.toggleSave(id, meta);
      u.toast(v ? 'Saved' : 'Removed from saved', 1400);
    } else if (b.dataset.a === 'copy') {
      u.copy(textOf(t)).then(function (ok) { u.toast(ok ? 'Copied' : 'Could not copy', 1300); });
    }
    sync();
  });

  /* ---------- Store badalne par DOM update ---------- */
  function applyMark(el, m) {
    for (var k = 1; k <= 4; k++) el.classList.toggle('hl' + k, !!m && m.c === k);
    el.classList.toggle('sv', !!(m && m.v));
    el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
  }
  store.on(function (id) {
    if (id == null) { if (NR.app && NR.app.refreshViews) NR.app.refreshViews(); return; }
    var p = store.parse(id), m = store.get(id);
    u.$$('.card[data-k="' + u.cssEsc(p.key) + '"]').forEach(function (card) {
      var inSaved = !!card.closest('#v-saved');
      if (p.t === 'c') {
        if (card.dataset.t !== 'c') return;
        applyMark(card, m);
        if (inSaved) card.classList.toggle('gone', !m);
      } else {
        var li = card.querySelector('li[data-i="' + p.i + '"]');
        if (!li) return;
        applyMark(li, m);
        if (inSaved && card.dataset.t === 'p') card.classList.toggle('gone', !m);
      }
    });
    if (NR.app) NR.app.updateBadge();
  });


  /* ---------- Status (read / revised / star) ---------- */
  function applyStatus(card, s) {
    card.classList.toggle('is-read', !!(s && s.r));
    card.classList.toggle('is-rev', !!(s && s.d));
    card.classList.toggle('is-star', !!(s && s.s));
  }
  NR.status.on(function (key) {
    if (key == null) { if (NR.app && NR.app.refreshViews) NR.app.refreshViews(); return; }
    var s = NR.status.get(key);
    u.$$('.card[data-t="c"][data-k="' + u.cssEsc(key) + '"]').forEach(function (c) { applyStatus(c, s); });
    if (NR.app && NR.app.statusChanged) NR.app.statusChanged();
    if (NR.reader) NR.reader.sync();
  });
  function keyOf(b) { var c = b.closest('.card'); return c ? c.dataset.k : null; }
  function flip(b, f, on, off) {
    var k = keyOf(b); if (!k) return;
    var v = NR.status.toggle(k, f);
    u.toast(v ? on : off, 1200);
  }
  NR.act['st-read'] = function (b) { flip(b, 'r', 'Marked as read ✓', 'Marked unread'); };
  NR.act['st-rev'] = function (b) { flip(b, 'd', 'Marked revised ↻', 'Revise mark removed'); };
  NR.act['st-star'] = function (b) { flip(b, 's', '★ Added to important', 'Star removed'); };
  NR.act['open-reader'] = function (b) { var k = keyOf(b); if (k && NR.reader) NR.reader.open(k); };

  /* ---------- Click / keyboard routing ---------- */
  function selectionActive() {
    var s = window.getSelection && window.getSelection();
    return !!(s && !s.isCollapsed && String(s).length > 0);
  }

  document.addEventListener('click', function (e) {
    var t = e.target;
    var act = t.closest('[data-act]');
    if (act) {
      var fn = NR.act[act.dataset.act];
      if (fn) { if (act.tagName === 'A') e.preventDefault(); fn(act, e); return; }
    }
    var li = t.closest('.pts li');
    if (li) {
      if (selOn) { NR.sel.toggle(idOf(li)); return; }
      if (selectionActive()) return;
      show(li); return;
    }
    var head = t.closest('.card-h');
    if (head && !t.closest('button, a')) {
      var card = head.parentNode;
      if (selOn && card.dataset.t === 'c') { NR.sel.toggle(idOf(card)); return; }
      if (card.dataset.t === 'c' && !selOn) { card.classList.toggle('folded'); hide(); return; }
    }
    hide();
  });

  document.addEventListener('keydown', function (e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.pts li')) {
      e.preventDefault();
      if (selOn) NR.sel.toggle(idOf(e.target)); else show(e.target);
    }
  });

  /* ---------- data-act handlers ---------- */
  NR.act['fold'] = function (b) { b.closest('.card').classList.toggle('folded'); hide(); };
  NR.act['card-save'] = function (b) {
    var card = b.closest('.card'), id = idOf(card);
    var v = store.toggleSave(id, metaOf(card));
    u.toast(v ? 'Card saved' : 'Removed from saved', 1400);
  };
  NR.act['card-tools'] = function (b) {
    var card = b.closest('.card');
    card.classList.remove('folded');
    show(b.closest('.card-f') || b.closest('.card-h'));
  };
  NR.act['pt-tools'] = function (b) {
    var li = b.closest('.card').querySelector('.pts li');
    if (li) show(li);
  };
  NR.act['toggle-select'] = function () {
    NR.sel.setMode(!selOn);
    u.toast(selOn ? 'Select mode on — tap cards or bullets to pick' : 'Select mode off', 1800);
  };
  NR.act['sel-clear'] = function () { NR.sel.clear(); };
  NR.act['sel-done'] = function () { NR.sel.setMode(false); };
  NR.act['sel-all'] = function () {
    var ids = NR.app.visibleIds();
    NR.sel.add(ids);
    u.toast(ids.length + ' cards selected', 1400);
  };
})(window.NR);

/* ======== 08-saved.js ======== */
/* saved.js — "Saved": saved + highlighted cards/bullets ka alag section. Apne-aap topic-wise sorted. */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, store = NR.store, cards = NR.cards, C = NR.config;
  var st = { kind: 'all', mark: 'all', color: 0 };
  var list, built = [], dirty = true;

  var SORTS = {
    auto:   'Auto: topic → note → point',
    recent: 'Recently added first',
    old:    'Oldest added first',
    color:  'By highlight colour',
    title:  'Title (A → Z)'
  };

  function entries() {
    var out = [], ckeys = new Set();
    if (st.kind === 'all') store.marks.forEach(function (m, id) { if (id.charAt(0) === 'c') ckeys.add(store.parse(id).key); });
    store.marks.forEach(function (m, id) {
      var p = store.parse(id);
      if (st.kind !== 'all' && p.t !== st.kind) return;
      if (p.t === 'p' && ckeys.has(p.key)) return;           // पूरा कार्ड Save है तो उसके बुलेट अलग नहीं दिखाते
      if (st.mark === 'hl' && !m.c) return;
      if (st.mark === 'sv' && !m.v) return;
      if (st.color && m.c !== st.color) return;
      var n = NR.model.byKey.get(p.key);
      out.push({ id: id, t: p.t, key: p.key, i: p.i, note: n, m: m,
                 o: [n ? n.topicOrder : 9999, n ? n.order : 9999, p.t === 'c' ? -1 : p.i] });
    });
    return out;
  }
  function byAuto(a, b) { return (a.o[0] - b.o[0]) || (a.o[1] - b.o[1]) || (a.o[2] - b.o[2]); }

  function rowsFor(es) {
    var sort = NR.prefs.get('savedSort'), rows = [], i;
    if (sort === 'recent') es.sort(function (a, b) { return b.m.t - a.m.t; });
    else if (sort === 'old') es.sort(function (a, b) { return a.m.t - b.m.t; });
    else if (sort === 'title') es.sort(function (a, b) {
      return NR.query.coll.compare(a.note ? a.note.sortTitle : '~', b.note ? b.note.sortTitle : '~') || byAuto(a, b);
    });
    else if (sort === 'color') es.sort(function (a, b) { return ((a.m.c || 9) - (b.m.c || 9)) || byAuto(a, b); });
    else es.sort(byAuto);

    if (sort === 'auto') {
      var last = null, grp = null;
      for (i = 0; i < es.length; i++) {
        var nm = es[i].note ? es[i].note.topic : 'Source unavailable';
        if (nm !== last) { grp = { h: nm, n: 0 }; rows.push(grp); last = nm; }
        grp.n++; rows.push({ e: es[i] });
      }
    } else if (sort === 'color') {
      var lc = -1, g2 = null;
      for (i = 0; i < es.length; i++) {
        var c = es[i].m.c || 0;
        if (c !== lc) { g2 = { h: c ? 'Highlight: ' + C.highlightColors[c - 1].name : 'Saved only (no colour)', n: 0, color: c }; rows.push(g2); lc = c; }
        g2.n++; rows.push({ e: es[i] });
      }
    } else {
      for (i = 0; i < es.length; i++) rows.push({ e: es[i] });
    }
    return rows;
  }

  function controls() {
    var cnt = store.counts();
    function seg(act, cur, items) {
      return '<div class="seg" role="group">' + items.map(function (it) {
        return '<button class="segb' + (String(cur) === String(it[0]) ? ' on' : '') + '" data-act="' + act + '" data-v="' + it[0] + '">' + it[1] + '</button>';
      }).join('') + '</div>';
    }
    var dots = '<div class="seg dots" role="group" aria-label="Colour filter">' +
      '<button class="segb' + (st.color === 0 ? ' on' : '') + '" data-act="sv-color" data-v="0">All colours</button>' +
      C.highlightColors.map(function (h) {
        return '<button class="segb dotb c' + h.id + (st.color === h.id ? ' on' : '') + '" data-act="sv-color" data-v="' + h.id + '" aria-label="' + h.name + '" title="' + h.name + '"><i></i></button>';
      }).join('') + '</div>';
    var opts = Object.keys(SORTS).map(function (k) {
      return '<option value="' + k + '"' + (NR.prefs.get('savedSort') === k ? ' selected' : '') + '>' + SORTS[k] + '</option>';
    }).join('');
    $('#savedBar').innerHTML =
      '<div class="sv-sum"><b>' + cnt.total + '</b> items <span>· ' + cnt.cards + ' cards · ' + cnt.points + ' points · ' + cnt.hl + ' highlights · ' + cnt.saved + ' saved</span></div>' +
      '<div class="sv-ctl">' +
      seg('sv-kind', st.kind, [['all', 'All'], ['c', 'Cards'], ['p', 'Points']]) +
      seg('sv-mark', st.mark, [['all', 'Both'], ['hl', 'Highlights'], ['sv', 'Saved']]) + dots +
      '<label class="selw"><svg class="i"><use href="#i-sort"/></svg><select id="savedSort" aria-label="Saved sort order">' + opts + '</select></label>' +
      '</div>';
  }

  function render() {
    dirty = false;
    controls();
    var es = entries(), rows = rowsFor(es);
    built = es;
    var folded = NR.prefs.get('fold');
    var empty = $('#savedEmpty');
    empty.hidden = es.length > 0;
    empty.innerHTML = store.marks.size
      ? '<h3>Nothing matches this filter</h3><p>Try changing the filters above.</p>'
      : '<h3>Nothing saved yet</h3><p>Tap any <b>bullet point</b> → pick a colour or press <b>bookmark</b>.<br>For a whole card, use the <b>pen / bookmark</b> buttons on the card.<br>Everything shows up here grouped by topic.</p>';
    list.set(rows, function (r, k) {
      if (r.h != null) return cards.group(r.h, r.n, 'items', true);
      var e = r.e;
      if (e.t === 'c' && e.note) return cards.note(e.note, { i: k, folded: folded });
      return cards.point(e, { i: k });
    });
  }

  NR.saved = {
    init: function () {
      list = new NR.IncList($('#savedList'), $('#savedSentinel'));
      store.on(function () { dirty = true; });
    },
    render: render,
    get dirty() { return dirty; },
    markDirty: function () { dirty = true; },
    entries: function () { return built; },
    set: function (k, v) { st[k] = v; render(); },
    state: st
  };

  NR.act['sv-kind'] = function (b) { NR.saved.set('kind', b.dataset.v); };
  NR.act['sv-mark'] = function (b) { NR.saved.set('mark', b.dataset.v); };
  NR.act['sv-color'] = function (b) { NR.saved.set('color', +b.dataset.v); };
  document.addEventListener('change', function (e) {
    if (e.target.id === 'savedSort') { NR.prefs.set('savedSort', e.target.value); render(); }
  });
})(window.NR);

/* ======== 09-modal.js ======== */
/* modal.js — halka modal/dialog manager (Esc, backdrop click, focus restore) */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, openStack = [], lastFocus = null;

  function open(id) {
    var m = $('#' + id);
    if (!m) return;
    lastFocus = document.activeElement;
    var t = $('#toast'); if (t) t.classList.remove('on');
    m.hidden = false;
    void m.offsetWidth;               // reflow -> transition chalega
    m.classList.add('on');
    document.documentElement.classList.add('modal-open');
    openStack.push(id);
    var f = m.querySelector('input:not([disabled]), select, button.btn');
    if (f) setTimeout(function () { try { f.focus({ preventScroll: true }); } catch (e) {} }, 60);
  }
  function close(id) {
    var m = $('#' + id);
    if (!m || m.hidden) return;
    m.classList.remove('on');
    var dur = document.documentElement.classList.contains('lite') ? 0 : 220;
    setTimeout(function () { if (!m.classList.contains('on')) m.hidden = true; }, dur);
    openStack = openStack.filter(function (x) { return x !== id; });
    if (!openStack.length) document.documentElement.classList.remove('modal-open');
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus({ preventScroll: true }); } catch (e) {} }
  }
  function closeTop() { if (openStack.length) { close(openStack[openStack.length - 1]); return true; } return false; }

  NR.modal = { open: open, close: close, closeTop: closeTop, get any() { return openStack.length > 0; } };
  NR.act['close-modal'] = function (b) {
    var m = b.closest('.modal');
    if (m) close(m.id);
  };
})(window.NR);

/* ======== 10-reader.js ======== */
/* reader.js — Read mode: ek-ek note poori screen par, bada text, swipe/next-prev, ✓ पढ़ा / ↻ रिवाइज़ / ★ स्टार */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, S = NR.status;
  var R = { on: false, list: [], i: 0 }, hist = false, el, scroller, body;

  function cur() { return R.list[R.i]; }

  function render(dir) {
    var n = cur(); if (!n) return;
    NR.actions.hide();
    body.innerHTML = NR.cards.reader(n);
    body.classList.remove('sl', 'sr');
    if (dir && !document.documentElement.classList.contains('lite')) {
      void body.offsetWidth; body.classList.add(dir > 0 ? 'sl' : 'sr');
    }
    scroller.scrollTop = 0;
    $('#rdTopic').textContent = n.topic;
    $('#rdPos').textContent = (R.i + 1) + ' / ' + R.list.length;
    $('#rdBar').style.transform = 'scaleX(' + ((R.i + 1) / R.list.length).toFixed(3) + ')';
    $('#rdPrev').disabled = R.i === 0;
    sync();
  }
  function sync() {
    if (!R.on) return;
    var n = cur(); if (!n) return;
    var s = S.get(n.key) || {};
    $('#rdRead').classList.toggle('on', !!s.r);
    $('#rdRev').classList.toggle('on', !!s.d);
    $('#rdStar').classList.toggle('on', !!s.s);
    $('#rdStar').setAttribute('aria-pressed', String(!!s.s));
  }

  function open(key, list) {
    list = (list && list.length) ? list : NR.app.currentList();
    var i = -1;
    for (var j = 0; j < list.length; j++) if (list[j].key === key) { i = j; break; }
    if (i < 0) { var n = NR.model.byKey.get(key); if (!n) return; list = [n]; i = 0; }
    R.list = list.slice(); R.i = i; R.on = true;
    el.hidden = false; void el.offsetWidth; el.classList.add('on');
    document.documentElement.classList.add('reading');
    render(0);
    try { history.pushState({ nrReader: 1 }, '', '#read'); hist = true; } catch (e) { hist = false; }
  }
  // Pehla aparhit note (ya shuru se) — "Read mode" button ke liye
  function start() {
    var list = NR.app.currentList();
    if (!list.length) { u.toast('No notes to read'); return; }
    var k = list[0].key;
    for (var i = 0; i < list.length; i++) if (!S.flag(list[i].key, 'r')) { k = list[i].key; break; }
    open(k, list);
  }
  function finish() {
    if (!R.on) return;
    R.on = false;
    NR.actions.hide();
    el.classList.remove('on');
    document.documentElement.classList.remove('reading');
    var lite = document.documentElement.classList.contains('lite');
    setTimeout(function () { if (!R.on) { el.hidden = true; body.innerHTML = ''; } }, lite ? 0 : 240);
    if (NR.app && NR.app.statusChanged) NR.app.statusChanged();
  }
  function close() {
    if (!R.on) return;
    if (hist && history.state && history.state.nrReader) { hist = false; history.back(); } else finish();
  }
  window.addEventListener('popstate', function () { hist = false; if (R.on) finish(); });

  function go(d) {
    var n = cur(), j = R.i + d;
    if (d > 0 && n && NR.prefs.get('autoRead') && !S.flag(n.key, 'r')) S.set(n.key, 'r', 1);
    if (j < 0) { u.toast('This is the first note', 1100); return; }
    if (j >= R.list.length) { u.toast('End of list 🎉', 1600); return; }
    R.i = j; render(d);
  }
  function tog(f, on, off) { var n = cur(); if (!n) return; u.toast(S.toggle(n.key, f) ? on : off, 1100); }

  NR.act['rd-close'] = close;
  NR.act['rd-prev'] = function () { go(-1); };
  NR.act['rd-next'] = function () { go(1); };
  NR.act['rd-read'] = function () { tog('r', 'Marked read ✓', 'Marked unread'); };
  NR.act['rd-rev'] = function () { tog('d', 'Marked revised ↻', 'Revise mark removed'); };
  NR.act['rd-star'] = function () { tog('s', '★ Marked important', 'Star removed'); };
  NR.act['rd-font'] = function (b) {
    var v = Math.max(14, Math.min(26, NR.prefs.get('fs') + (+b.dataset.d)));
    NR.prefs.set('fs', v); NR.settings.apply();
  };
  NR.act['read-start'] = start;

  document.addEventListener('keydown', function (e) {
    if (!R.on) return;
    if (e.key === 'ArrowRight') { go(1); e.preventDefault(); }
    else if (e.key === 'ArrowLeft') { go(-1); e.preventDefault(); }
  });

  function init() {
    el = $('#reader'); scroller = $('#rdScroll'); body = $('#rdBody');
    var x0 = 0, y0 = 0, t0 = 0;
    scroller.addEventListener('touchstart', function (e) { var t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; t0 = Date.now(); }, { passive: true });
    scroller.addEventListener('touchend', function (e) {
      var t = e.changedTouches[0], dx = t.clientX - x0, dy = t.clientY - y0;
      if (Date.now() - t0 < 700 && Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.8) go(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  NR.reader = { init: init, open: open, start: start, close: close, sync: sync, get on() { return R.on; } };
})(window.NR);

/* ======== 11-stats.js ======== */
/* stats.js — Exam prep insights: वेटेज (pie), प्राथमिकता, दोGreenए कांसेप्ट, जाल-क्षेत्र, परीक्षा-स्रोत, प्रगति.
   Static हिस्सा (compute) एक बार, dynamic हिस्सा (प्रगति/स्कोर) हर बार हल्का. */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, esc = u.esc, md = NR.md, C = NR.config, fmt = u.fmt, S = NR.status, prefs = NR.prefs;
  var STOP = new Set(C.stopwords), GEN = new Set(C.genericTerms);
  var WORD = /[ऀ-ॿ]{3,}|[A-Za-z][A-Za-z0-9₀-₉]+/g;
  var BOLD = /\*\*([^*]+?)\*\*/g;
  var PAREN_EX = /\([^)]*\b(?:MTS|CHSL|CGL|GD|CPO|DP|Steno|Selection Post)\b[^)]*\)/g;
  var cache = { ver: -1, R: null }, busy = false, pending = false, st = { subj: '' };

  function boldHead(t) {
    t = t.replace(/^[\s🧠➕⚠️📌🎯]+/u, '').replace(/[\s:：–\-—।,.]+$/g, '').trim();
    var h = t.replace(/\s*[(（].*$/, '').trim();
    return h.length >= 2 ? h : t;
  }

  /* ---------------- compute (static) ---------------- */
  async function compute(notes, onProgress) {
    var R = { N: notes.length, nFacts: 0, topics: new Map(), subj: new Map(), terms: new Map(), exams: new Map(), repeatLines: [], trapNotes: [] };
    function topicOf(n) {
      var t = R.topics.get(n.tk);
      if (!t) {
        t = { key: n.tk, name: n.topic, subj: n.subj, order: n.topicOrder, facts: 0, pts: 0, mtsN: 0, othN: 0, trap: 0, mn: 0, extra: 0, est: 0, decl: null, keys: [], metaKey: null, rep: 0 };
        R.topics.set(n.tk, t);
      }
      return t;
    }
    await NR.sched.chunk(notes, function (n) {
      var t = topicOf(n); t.keys.push(n.key);
      if (n.meta) {
        if (!t.metaKey) t.metaKey = n.key;
        if (n.decl && !t.decl) t.decl = n.decl;
        for (var j = 0; j < n.lines.length; j++) {
          var tx = md.strip(n.lines[j].t);
          if (C.repeatLineRe.test(tx)) R.repeatLines.push({ n: n, i: j, t: tx });
        }
        return;
      }
      R.nFacts++; t.facts++; t.pts += n.pts;
      if (n.tags.indexOf('mts') >= 0) t.mtsN++; else t.othN++;
      t.est += Math.max(1, n.exTotal);
      var tr = (n.mk.trap || 0) + (n.mk.warn || 0);
      t.trap += tr; t.mn += n.mk.mnemonic || 0; t.extra += n.mk.extra || 0;
      if (tr) R.trapNotes.push({ n: n, c: tr });
      if (n.ex) for (var e in n.ex) R.exams.set(e, (R.exams.get(e) || 0) + n.ex[e]);

      // concepts: bold terms + content words, per-note (document frequency)
      var seen = new Map(), k;
      for (var i = 0; i < n.lines.length; i++) {
        var raw = n.lines[i].t, m;
        BOLD.lastIndex = 0;
        while ((m = BOLD.exec(raw))) {
          var h = boldHead(m[1]);
          if (h.length >= 2 && h.length <= 30 && !GEN.has(h) && !STOP.has(h)) seen.set(h, true);
        }
        var ws = md.strip(raw).replace(PAREN_EX, ' ').match(WORD);
        if (ws) for (var q = 0; q < ws.length; q++) {
          var w = ws[q];
          if (STOP.has(w) || STOP.has(w.toLowerCase()) || GEN.has(w)) continue;
          if (!seen.has(w)) seen.set(w, false);
        }
      }
      var hasM = n.tags.indexOf('mts') >= 0;
      seen.forEach(function (bold, term) {
        var e = R.terms.get(term);
        if (!e) { e = { term: term, n: 0, mts: 0, oth: 0, bold: false, topics: new Set() }; R.terms.set(term, e); }
        e.n++; if (hasM) e.mts++; else e.oth++;
        if (bold) e.bold = true;
        e.topics.add(n.tk);
      });
    }, { onProgress: onProgress });

    // topic weights
    R.topics.forEach(function (t, k) {
      if (!t.facts) { R.topics.delete(k); return; }
      t.declared = !!t.decl;
      t.q = t.decl ? t.decl.q : t.est;
      t.qm = t.decl ? t.decl.mts : t.mtsN;
      var s = R.subj.get(t.subj);
      if (!s) { s = { name: t.subj, topics: [] }; R.subj.set(t.subj, s); }
      s.topics.push(t);
    });

    // concept groups
    var cap = Math.max(4, R.nFacts * 0.4), both = [], cross = [], mo = [], oo = [];
    R.terms.forEach(function (e) {
      var min = e.bold ? 2 : 3;
      if (e.n < min || e.n > cap) return;
      e.score = e.n + e.topics.size * 0.5 + (e.bold ? 0.6 : 0);
      if (e.mts && e.oth) both.push(e);
      else if (e.topics.size >= 2) cross.push(e);
      else if (e.mts) mo.push(e);
      else oo.push(e);
    });
    function srt(a) { a.sort(function (x, y) { return y.score - x.score || x.term.localeCompare(y.term); }); return a; }
    R.groups = { both: srt(both), cross: srt(cross), mts: srt(mo), oth: srt(oo) };
    // topic-wise "doharaye concept" ginti
    [both.slice(0, 30), cross.slice(0, 20)].forEach(function (arr) {
      arr.forEach(function (e) { e.topics.forEach(function (tk) { var t = R.topics.get(tk); if (t) t.rep++; }); });
    });
    R.trapNotes.sort(function (a, b) { return b.c - a.c; });
    return R;
  }

  /* ---------------- html helpers ---------------- */
  function hueAt(i) { return Math.round((i * 137.5 + 24) % 360); }
  function pctOf(a, b) { return b ? Math.round(a / b * 100) : 0; }
  function panel(id, ico, title, desc, body, cls) {
    return '<section class="panel ' + (cls || '') + '" id="' + id + '"><header class="panel-h"><span class="panel-i">' + NR.cards.ic(ico) + '</span><div><h3>' + title + '</h3>' +
      (desc ? '<p>' + desc + '</p>' : '') + '</div></header>' + body + '</section>';
  }
  function insight(html) { return '<p class="insight">' + NR.cards.ic('bolt') + '<span>' + html + '</span></p>'; }
  function bar(label, val, max, sub, cls, act) {
    var w = max ? Math.max(0.03, val / max) : 0;
    var inner = '<span class="bl">' + label + '</span><span class="bt"><i class="' + (cls || '') + '" style="--w:' + w.toFixed(3) + '"></i></span><span class="bv">' + fmt(val) + (sub ? '<small>' + sub + '</small>' : '') + '</span>';
    return act ? '<button class="brow" ' + act + '>' + inner + '</button>' : '<div class="brow">' + inner + '</div>';
  }

  function donut(items, total, center, sub, actName) {
    var acc = 0, segs = '';
    items.forEach(function (it, i) {
      var p = total ? it.v / total * 100 : 0, len = Math.max(0, p - (items.length > 1 ? 0.6 : 0));
      segs += '<circle class="arc" style="--ph:' + hueAt(i) + '" r="15.9155" cx="21" cy="21" pathLength="100" stroke-dasharray="' + len.toFixed(2) + ' ' + (100 - len).toFixed(2) +
        '" stroke-dashoffset="' + (25 - acc).toFixed(2) + '"><title>' + esc(it.l) + ': ' + fmt(it.v) + ' (' + Math.round(p) + '%)</title></circle>';
      acc += p;
    });
    var leg = items.map(function (it, i) {
      var inner = '<i class="dot" style="--ph:' + hueAt(i) + '"></i><span class="lg-n">' + esc(it.l) + '</span><b>' + fmt(it.v) + '</b><small>' + pctOf(it.v, total) + '%</small>';
      return '<li>' + (it.act ? '<button class="lg" ' + it.act + '>' + inner + '</button>' : '<div class="lg">' + inner + '</div>') + '</li>';
    }).join('');
    return '<div class="donut-w"><svg viewBox="0 0 42 42" class="donut" role="img" aria-label="' + esc(center) + '"><circle r="15.9155" cx="21" cy="21" fill="none" class="track"/>' + segs +
      '<text x="21" y="21.6" text-anchor="middle" class="d-n">' + fmt(total) + '</text><text x="21" y="26.6" text-anchor="middle" class="d-l">' + esc(sub || '') + '</text></svg><ul class="legend">' + leg + '</ul></div>';
  }

  function seg(act, cur, items) {
    return '<div class="seg" role="group">' + items.map(function (it) {
      return '<button class="segb' + (String(cur) === String(it[0]) ? ' on' : '') + '" data-act="' + act + '" data-v="' + esc(it[0]) + '">' + esc(it[1]) + '</button>';
    }).join('') + '</div>';
  }

  var METRICS = { q: ['All exams', 'PYQ'], mts: ['MTS only', 'MTS PYQ'], notes: ['Notes', 'notes'] };
  function wval(t, m) { return m === 'mts' ? t.qm : m === 'notes' ? t.facts : t.q; }
  function tier(score) { return score >= 60 ? ['hi', 'High priority'] : score >= 35 ? ['mid', 'Medium'] : ['lo', 'Later']; }

  function progOf(t) {
    var r = 0, d = 0, n = t.keys.length;
    for (var i = 0; i < n; i++) { var m = S.get(t.keys[i]); if (m && m.r) { r++; if (m.d) d++; } }
    return { n: n, r: r, d: d, un: n - r };
  }

  /* ---------------- view (dynamic) ---------------- */
  function view(R) {
    var metric = prefs.get('wmetric'); if (!METRICS[metric]) metric = 'q';
    var subjNames = Array.from(R.subj.keys());
    if (st.subj && !R.subj.has(st.subj)) st.subj = '';
    var topics = Array.from(R.topics.values()).filter(function (t) { return !st.subj || t.subj === st.subj; }).sort(function (a, b) { return a.order - b.order; });
    var h = '';

    // metric fallback: agar sab 0 ho
    var totalW = topics.reduce(function (s, t) { return s + wval(t, metric); }, 0);
    if (!totalW) { metric = 'notes'; totalW = topics.reduce(function (s, t) { return s + t.facts; }, 0); }
    var unit = METRICS[metric][1];
    var anyDecl = topics.some(function (t) { return t.declared; }), allDecl = topics.every(function (t) { return t.declared; });

    // priority score
    var maxW = Math.max.apply(null, topics.map(function (t) { return wval(t, metric); }).concat([1]));
    var dens = topics.map(function (t) { return t.trap / Math.max(1, t.pts); });
    var maxD = Math.max.apply(null, dens.concat([0.0001])), maxRep = Math.max.apply(null, topics.map(function (t) { return t.rep; }).concat([1]));
    topics.forEach(function (t, i) {
      t.score = Math.round(100 * (0.5 * wval(t, metric) / maxW + 0.2 * dens[i] / maxD + 0.3 * t.rep / maxRep));
      t.pg = progOf(t);
    });
    var ranked = topics.slice().sort(function (a, b) { return b.score - a.score || a.order - b.order; });

    /* 1) Hero: progress + next step */
    var all = NR.model.notes, c = S.counts(all);
    var rp = pctOf(c.read, c.n), vp = pctOf(c.rev, c.n);
    var nextT = null;
    for (var i = 0; i < ranked.length; i++) if (ranked[i].pg.un > 0) { nextT = ranked[i]; break; }
    h += '<div class="hero"><div class="ring" style="--p:' + rp + '"><b>' + rp + '%</b><small>read</small></div><div class="hero-t"><h3>Your progress</h3>' +
      '<p><b>' + c.read + '</b> / ' + c.n + ' notes read · <b>' + c.rev + '</b> revised (' + vp + '%)</p>' +
      '<div class="hero-chips"><span class="pill todo">↻ To revise ' + c.todo + '</span><span class="pill star">★ Starred ' + c.star + '</span><span class="pill un">Unread ' + c.unread + '</span></div></div></div>';
    if (nextT) {
      var tr = tier(nextT.score);
      h += '<div class="next"><div><small>Next up</small><b>' + esc(nextT.name) + '</b><span class="tier ' + tr[0] + '">' + tr[1] + '</span>' +
        '<p>' + nextT.pg.un + ' unread · ' + fmt(wval(nextT, metric)) + ' ' + unit + ' (' + pctOf(wval(nextT, metric), totalW) + '%)</p></div>' +
        '<button class="btn pri" data-act="st-read-topic" data-v="' + esc(nextT.key) + '">' + NR.cards.ic('play') + 'Start reading</button></div>';
    } else if (c.n) {
      h += '<div class="next done"><div><b>🎉 You have read every topic</b><p>Now focus on ↻ revision and ★ important notes.</p></div></div>';
    }

    /* 2) Overall subject weightage */
    var subjItems = subjNames.map(function (nm) {
      var ts = R.subj.get(nm).topics, v = ts.reduce(function (s, t) { return s + wval(t, metric); }, 0);
      return { l: nm, v: v, ts: ts, act: 'data-act="st-subj" data-v="' + esc(nm) + '"' };
    });
    var subjTotal = subjItems.reduce(function (s, x) { return s + x.v; }, 0);
    var srows = subjItems.map(function (x) {
      var nn = x.ts.reduce(function (s, t) { return s + t.keys.length; }, 0), rr = x.ts.reduce(function (s, t) { return s + progOf(t).r; }, 0);
      var tp = x.ts.slice().sort(function (a, b) { return wval(b, metric) - wval(a, metric); })[0];
      return '<button class="srow" data-act="st-subj" data-v="' + esc(x.l) + '"><b>' + esc(x.l) + '</b><span>' + x.ts.length + ' topics · heaviest: ' + esc(tp ? tp.name : '—') +
        '</span><span class="mini"><i style="--w:' + (nn ? rr / nn : 0).toFixed(3) + '"></i></span><em>' + pctOf(rr, nn) + '% read</em></button>';
    }).join('');
    h += panel('st-subj', 'pie', 'Subject-wise weightage (overall)', 'Share of each subject — based on ' + esc(METRICS[metric][0]) + '.',
      (subjNames.length > 1 ? donut(subjItems.map(function (x) { return { l: x.l, v: x.v, act: x.act }; }), subjTotal, 'Subject', unit) : '<p class="big-n"><b>' + fmt(subjTotal) + '</b> ' + esc(unit) + ' · ' + topics.length + ' topics</p>') +
      '<div class="srows">' + srows + '</div>' +
      (subjNames.length < 2 ? '<p class="hint">Only one subject is loaded. Add another <code>data_*.js</code> file to compare subjects here.</p>' : ''));

    /* 3) Topic weightage pie */
    var items = topics.map(function (t) { return { l: t.name, v: wval(t, metric), act: 'data-act="st-topic" data-v="' + esc(t.key) + '"' }; })
      .sort(function (a, b) { return b.v - a.v; }).filter(function (x) { return x.v > 0; });
    var top3 = items.slice(0, 3), top3p = pctOf(top3.reduce(function (s, x) { return s + x.v; }, 0), totalW);
    var tctl = '<div class="ctl">' + seg('st-metric', metric, Object.keys(METRICS).map(function (k) { return [k, METRICS[k][0]]; })) +
      (subjNames.length > 1 ? seg('st-subjsel', st.subj, [['', 'All subjects']].concat(subjNames.map(function (s) { return [s, s]; }))) : '') + '</div>';
    var src = metric === 'notes' ? 'Based on the number of notes.' :
      allDecl ? 'Based on the PYQ counts recorded in your pattern notes.' : anyDecl ? 'Based on recorded pattern-note counts (estimated from exam mentions where missing).' : 'Estimated from exam mentions in the notes.';
    h += panel('st-topic', 'pie', 'Topic-wise weightage', 'How many questions come from each topic. ' + src,
      tctl + donut(items, totalW, 'Topic', unit) +
      (items.length ? insight('<b>' + esc(items[0].l) + '</b> is the heaviest — ' + pctOf(items[0].v, totalW) + '% of the total. ' +
        (items.length > 3 ? 'Top ' + top3.length + ' topics (' + top3.map(function (x) { return esc(x.l); }).join(', ') + ') together make ' + top3p + '% — master these first.' : '')) : ''));

    /* 4) Priority list */
    var pr = ranked.map(function (t, i) {
      var tr = tier(t.score), share = pctOf(wval(t, metric), totalW);
      return '<button class="prow" data-act="st-topic" data-v="' + esc(t.key) + '"><span class="rk">' + (i + 1) + '</span><div class="pb"><div class="pt"><b>' + esc(t.name) + '</b><span class="tier ' + tr[0] + '">' + tr[1] + '</span></div>' +
        '<div class="pm">' + fmt(wval(t, metric)) + ' ' + unit + ' (' + share + '%) · ' + t.rep + ' repeated concepts · ' + t.trap + ' trap points</div>' +
        '<div class="stack"><i class="s-rv" style="--w:' + (t.pg.n ? t.pg.d / t.pg.n : 0).toFixed(3) + '"></i><i class="s-rd" style="--w:' + (t.pg.n ? (t.pg.r - t.pg.d) / t.pg.n : 0).toFixed(3) + '"></i></div></div>' +
        '<span class="pg">' + t.pg.r + '/' + t.pg.n + '</span></button>';
    }).join('');
    h += panel('st-prio', 'flag', 'Study priority', 'Score = PYQ weightage (50%) + repeated concepts (30%) + trap density (20%). Topics at the top come first.', '<div class="prows">' + pr + '</div>');

    /* 5) Repeated concepts */
    var G = R.groups;
    function chips(arr, n) {
      return '<div class="cloud">' + arr.slice(0, n).map(function (e) {
        return '<button class="kw' + (e.mts && e.oth ? ' both' : '') + '" data-act="st-search" data-v="' + esc(e.term) + '" title="' + e.n + ' notes · ' + e.topics.size + ' Topic">' + esc(e.term) + '<sup>' + e.n + '</sup></button>';
      }).join('') + '</div>';
    }
    var cb = '';
    if (G.both.length) cb += '<h4 class="sub"><span class="dot both"></span>In both MTS and other exams</h4>' + chips(G.both, 16) +
      insight('The concepts above (top repeats among <b>' + G.both.length + '</b> shared terms) appear in both MTS and other-exam notes — asked repeatedly across exams. <b>Master these first.</b>');
    if (G.cross.length) cb += '<h4 class="sub"><span class="dot cross"></span>Concepts spanning several topics</h4>' + chips(G.cross, 14) +
      insight('These terms appear in more than one topic — they are <b>core concepts</b>. Understand them once and many topics get easier.');
    if (G.mts.length) cb += '<h4 class="sub"><span class="dot mts"></span>Repeated in MTS (MTS notes only)</h4>' + chips(G.mts, 10) +
      insight('Frequent in MTS notes — revise these separately if you are preparing for MTS.');
    if (G.oth.length) cb += '<h4 class="sub"><span class="dot oth"></span>Repeated in other exams</h4>' + chips(G.oth, 10) +
      insight('Frequent in exams like CHSL/CGL/GD — useful for statement/analysis questions.');
    if (R.repeatLines.length) {
      cb += '<h4 class="sub"><span class="dot rep"></span>Facts repeated per pattern notes</h4><ul class="replist">' + R.repeatLines.slice(0, 8).map(function (r) {
        var t = r.t.length > 170 ? r.t.slice(0, 168) + '…' : r.t;
        return '<li><a href="#notes" data-act="goto" data-k="' + esc(r.n.key) + '" data-i="' + r.i + '"><span class="chip topic" style="--h:' + u.hue(r.n.topic) + '">' + esc(r.n.topic) + '</span>' + esc(t) + '</a></li>';
      }).join('') + '</ul>';
    }
    if (!cb) cb = '<p class="hint">Not enough notes yet to detect repeated concepts.</p>';
    h += panel('st-rep', 'repeat', 'Frequently repeated concepts', 'Terms and concepts that recur across different notes (number = how many notes). Tap to open those notes.', cb);

    /* 6) Traps */
    var trapT = topics.filter(function (t) { return t.trap; }).sort(function (a, b) { return b.trap / b.pts - a.trap / a.pts; }).slice(0, 8);
    var mxT = trapT.length ? trapT[0].trap / trapT[0].pts * 10 : 0;
    var scopeNotes = R.trapNotes.filter(function (x) { return !st.subj || x.n.subj === st.subj; }).slice(0, 5);
    var tb = trapT.map(function (t) { return bar(esc(t.name), +(t.trap / t.pts * 10).toFixed(1), mxT, t.trap + ' traps', 'c6', 'data-act="st-topic" data-v="' + esc(t.key) + '"'); }).join('');
    var tn = scopeNotes.map(function (x) {
      return '<li><a href="#notes" data-act="goto" data-k="' + esc(x.n.key) + '">' + esc(md.strip(x.n.title)) + '</a><b>' + x.c + ' traps</b></li>';
    }).join('');
    if (tb) h += panel('st-trap', 'warn', 'Error zones (confusions / traps)', 'Where options mislead. Number = trap points per 10 points.',
      '<div class="brows">' + tb + '</div><h4 class="sub">Notes with the most traps</h4><ol class="toplist">' + tn + '</ol>' +
      insight('<b>' + esc(trapT[0].name) + '</b> has the densest traps — pay special attention to look-alike options and trap points.'));

    /* 7) Exam source */
    var exArr = Array.from(R.exams.entries()).filter(function (x) { return x[0] !== 'MTS'; }).sort(function (a, b) { return b[1] - a[1]; });
    if (exArr.length) {
      var sumM = 0, sumO = 0;
      R.topics.forEach(function (t) { if (t.decl) { sumM += t.decl.mts; sumO += t.decl.oth; } });
      var exTot = exArr.reduce(function (s, x) { return s + x[1]; }, 0);
      var top = exArr[0];
      h += panel('st-exam', 'pie', 'Share of other exams', 'How often exams other than MTS are cited in the notes.',
        donut(exArr.map(function (x) { return { l: x[0], v: x[1] }; }), exTot, 'mentions', 'mentions') +
        insight('Most cited: <b>' + esc(top[0]) + '</b> (' + top[1] + ').' + (sumM + sumO ? ' In recorded PYQs: MTS <b>' + sumM + '</b> vs other exams <b>' + sumO + '</b> — other exams ask statement/analysis questions, MTS asks direct one-line facts.' : '')));
    }

    /* 8) My progress by topic + starred */
    var pb = topics.map(function (t) {
      var p = t.pg;
      return '<button class="prog-row" data-act="st-topic" data-v="' + esc(t.key) + '"><span class="pn2">' + esc(t.name) + '</span><span class="stack"><i class="s-rv" style="--w:' + (p.n ? p.d / p.n : 0).toFixed(3) + '"></i><i class="s-rd" style="--w:' +
        (p.n ? (p.r - p.d) / p.n : 0).toFixed(3) + '"></i></span><span class="pg">' + p.r + '/' + p.n + '</span></button>';
    }).join('');
    var stars = all.filter(function (n) { return S.flag(n.key, 's'); }).slice(0, 6);
    h += panel('st-me', 'check', 'My progress', '<span class="key"><i class="s-rv"></i>Revised</span> <span class="key"><i class="s-rd"></i>Read (to revise)</span> <span class="key"><i class="s-un"></i>Unread</span>',
      '<div class="prog-rows">' + pb + '</div>' +
      (stars.length ? '<h4 class="sub">★ Important notes</h4><ol class="toplist">' + stars.map(function (n) { return '<li><a href="#notes" data-act="goto" data-k="' + esc(n.key) + '">' + esc(md.strip(n.title)) + '</a><b>' + esc(n.topic) + '</b></li>'; }).join('') + '</ol>' : ''));
    return h;
  }

  /* ---------------- render ---------------- */
  async function render(force) {
    var host = u.$('#statsBody'), prog = u.$('#statsProg');
    if (!host) return;
    if (busy) { pending = true; return; }
    if (!NR.model.notes.length) { host.innerHTML = '<div class="empty on"><h3>No notes to analyse</h3><p>Add a data file first.</p></div>'; return; }
    if (force || cache.ver !== NR.model.version) {
      busy = true; prog.hidden = false;
      var bar_ = prog.firstElementChild;
      cache.R = await compute(NR.model.notes, function (i, n) { bar_.style.transform = 'scaleX(' + (i / n) + ')'; });
      cache.ver = NR.model.version;
      prog.hidden = true; busy = false;
    }
    var y = window.scrollY;
    host.classList.remove('in');
    host.innerHTML = view(cache.R);
    requestAnimationFrame(function () { host.classList.add('in'); });
    if (y) window.scrollTo(0, y);
    if (pending) { pending = false; render(); }
  }

  NR.stats = { render: render, invalidate: function () { cache = { ver: -1, R: null }; } };
  NR.act['st-metric'] = function (b) { prefs.set('wmetric', b.dataset.v); render(); };
  NR.act['st-subjsel'] = function (b) { st.subj = b.dataset.v; render(); };
  NR.act['st-subj'] = function (b) { st.subj = b.dataset.v; render().then(function () { var p = u.$('#st-topic'); if (p) p.scrollIntoView({ block: 'start' }); }); };
  NR.act['st-topic'] = function (b) { NR.app.openTopic(b.dataset.v); };
  NR.act['st-search'] = function (b) { NR.app.searchFor(b.dataset.v); };
  NR.act['st-read-topic'] = function (b) {
    var tk = b.dataset.v, list = NR.model.notes.filter(function (n) { return n.tk === tk; });
    var first = list.filter(function (n) { return !S.flag(n.key, 'r'); })[0] || list[0];
    if (first) NR.reader.open(first.key, list);
  };
})(window.NR);

/* ======== 12-exporter.js ======== */
/* exporter.js — PDF export (selected / highlighted / saved / current view / all).
   Browser ke print-engine se PDF banta hai => Hindi (Devanagari) ek-dum sahi, koi library/internet nahi chahiye. */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, esc = u.esc, md = NR.md, store = NR.store, C = NR.config;

  var DEF = { src: 'hl', title: '', group: true, tags: true, colors: true, brk: false, fs: 12, cols: 1, paper: 'A4', srcline: true };
  var opts = Object.assign({}, DEF, (NR.prefs.get('ex') || {}));

  /* ---------- Data collect ---------- */
  function collect(src) {
    var map = new Map();   // key -> { note, all, idx:Set, cm }
    function ent(note) {
      var e = map.get(note.key);
      if (!e) { e = { note: note, all: false, idx: new Set() }; map.set(note.key, e); }
      return e;
    }
    function addId(id) {
      var p = store.parse(id), n = NR.model.byKey.get(p.key);
      if (!n) return;
      if (p.t === 'c') ent(n).all = true;
      else if (n.lines[p.i]) ent(n).idx.add(p.i);
    }
    if (src === 'sel') NR.sel.ids().forEach(addId);
    else if (src === 'hl') store.marks.forEach(function (m, id) { if (m.c) addId(id); });
    else if (src === 'sv') store.marks.forEach(function (m, id) { if (m.v) addId(id); });
    else if (src === 'mine') store.marks.forEach(function (m, id) { addId(id); });
    else {
      var list = src === 'view' && NR.app ? NR.app.currentList() : NR.model.notes;
      list.forEach(function (n) { ent(n).all = true; });
    }
    var arr = Array.from(map.values()).sort(function (a, b) {
      return opts.group ? ((a.note.topicOrder - b.note.topicOrder) || (a.note.order - b.note.order)) : (a.note.order - b.note.order);
    });
    return arr;
  }
  function stat(arr) {
    var pts = 0;
    arr.forEach(function (e) { pts += e.all ? e.note.lines.length : e.idx.size; });
    return { notes: arr.length, pts: pts };
  }

  /* ---------- Print HTML ---------- */
  function lineHtml(n, i, o) {
    var ln = n.lines[i], m = store.get(store.pid(n.key, i));
    var cls = [];
    if (ln.k) cls.push('k-' + ln.k);
    if (ln.l) cls.push('l2');
    if (ln.p) cls.push('np');
    if (o.colors && m && m.c) cls.push('hl' + m.c);
    return '<li' + (cls.length ? ' class="' + cls.join(' ') + '"' : '') + '>' + md.inline(ln.t) + '</li>';
  }
  function noteHtml(e, o) {
    var n = e.note, cm = store.get(store.cid(n.key)), idx = [];
    if (e.all) for (var i = 0; i < n.lines.length; i++) idx.push(i);
    else idx = Array.from(e.idx).sort(function (a, b) { return a - b; });
    var tags = '';
    if (o.tags) tags = n.tags.map(function (t) { return '<span class="pr-tag">' + esc((C.tagLabels[t] && C.tagLabels[t].label) || t) + '</span>'; }).join('');
    var cc = (o.colors && cm && cm.c) ? ' hl' + cm.c : '';
    return '<article class="pr-note' + (e.all ? '' : ' part') + '"><h3 class="' + cc.trim() + '">' + md.inline(n.title) + tags + '</h3><ul>' +
      idx.map(function (i) { return lineHtml(n, i, o); }).join('') + '</ul></article>';
  }
  function build(o) {
    var arr = collect(o.src), s = stat(arr), h = '';
    var subj = Array.from(NR.model.subjects.keys()).join(', ');
    var title = o.title || ('Notes — ' + subj);
    h += '<header class="pr-head"><h1>' + esc(title) + '</h1><div class="pr-sub">' +
      new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) + ' · ' + s.notes + ' notes · ' + s.pts + ' points</div></header>';
    if (o.group) {
      var last = null, open = false;
      arr.forEach(function (e) {
        if (e.note.tk !== last) {
          if (open) h += '</section>';
          h += '<section class="pr-sec' + (o.brk ? ' brk' : '') + '"><h2>' + esc(e.note.topic) + '</h2>';
          open = true; last = e.note.tk;
        }
        h += noteHtml(e, o);
      });
      if (open) h += '</section>';
    } else {
      arr.forEach(function (e) { h += noteHtml(e, o); });
    }
    return { html: '<div class="pr-doc" style="--pr-fs:' + o.fs + 'pt;--pr-cols:' + o.cols + '">' + h + '</div>', stat: s, title: title, arr: arr };
  }

  function plainText(o) {
    var arr = collect(o.src), out = [];
    arr.forEach(function (e) {
      var n = e.note, idx = [];
      if (e.all) for (var i = 0; i < n.lines.length; i++) idx.push(i); else idx = Array.from(e.idx).sort(function (a, b) { return a - b; });
      out.push(md.strip(n.title) + '  [' + n.topic + ']');
      idx.forEach(function (i) { out.push('  • ' + md.strip(n.lines[i].t)); });
      out.push('');
    });
    return out.join('\n');
  }

  /* ---------- Modal UI ---------- */
  function counts() {
    var c = store.counts(), v = NR.app ? NR.app.currentList().length : 0;
    var set = { sel: NR.sel.size, hl: c.hl, sv: c.saved, mine: c.total, view: v, all: NR.model.notes.length };
    Object.keys(set).forEach(function (k) {
      var el = $('#exN-' + k); if (el) el.textContent = set[k];
      var inp = $('input[name="exSrc"][value="' + k + '"]');
      if (inp) { inp.disabled = !set[k]; inp.closest('.opt').classList.toggle('dis', !set[k]); }
    });
    return set;
  }
  function readForm() {
    var f = $('#mExport');
    opts.src = ($('input[name="exSrc"]:checked', f) || {}).value || 'all';
    opts.title = $('#exTitle').value.trim();
    opts.group = $('#exGroup').checked; opts.tags = $('#exTags').checked; opts.colors = $('#exColors').checked;
    opts.brk = $('#exBrk').checked;
    opts.fs = +$('#exFs').value; opts.cols = +$('#exCols').value; opts.paper = $('#exPaper').value;
    return opts;
  }
  function writeForm(set) {
    var f = $('#mExport');
    var pick = opts.src;
    if (!set[pick]) pick = set.sel ? 'sel' : set.hl ? 'hl' : set.sv ? 'sv' : set.view ? 'view' : 'all';
    var inp = $('input[name="exSrc"][value="' + pick + '"]', f); if (inp) inp.checked = true;
    $('#exTitle').value = opts.title; $('#exGroup').checked = opts.group; $('#exTags').checked = opts.tags;
    $('#exColors').checked = opts.colors; $('#exBrk').checked = opts.brk;
    $('#exFs').value = opts.fs; $('#exCols').value = opts.cols; $('#exPaper').value = opts.paper;
  }
  function summary() {
    readForm();
    var s = stat(collect(opts.src));
    $('#exSummary').innerHTML = '<b>' + s.notes + '</b> notes · <b>' + s.pts + '</b> points will go into the PDF';
    $('#exGo').disabled = !s.notes;
    return s;
  }

  function print() {
    readForm();
    NR.prefs.set('ex', opts);
    var b = build(opts);
    if (!b.stat.notes) { u.toast('Nothing selected to export'); return; }
    var root = $('#print-root');
    root.innerHTML = b.html;
    var st = $('#prPage');
    if (!st) { st = document.createElement('style'); st.id = 'prPage'; document.head.appendChild(st); }
    st.textContent = '@page{size:' + opts.paper + ';margin:14mm 12mm 16mm}';
    var old = document.title;
    document.title = b.title.replace(/[\\/:*?"<>|]+/g, ' ').slice(0, 80);
    function after() {
      window.removeEventListener('afterprint', after);
      document.title = old;
      root.innerHTML = '';
    }
    window.addEventListener('afterprint', after);
    NR.modal.close('mExport');
    setTimeout(function () { window.print(); }, 160);
  }

  NR.exporter = {
    open: function () {
      var set = counts();
      writeForm(set);
      summary();
      NR.modal.open('mExport');
    },
    build: function (o) { return build(Object.assign({}, DEF, o)); },
    print: print, summary: summary
  };

  NR.act['open-export'] = function () { NR.exporter.open(); };
  NR.act['export-go'] = print;
  NR.act['export-copy'] = function () {
    readForm();
    var t = plainText(opts);
    if (!t) { u.toast('Nothing selected'); return; }
    u.copy(t).then(function (ok) { u.toast(ok ? 'Text copied' : 'Could not copy'); });
  };
  document.addEventListener('change', function (e) { if (e.target.closest && e.target.closest('#mExport')) summary(); });
  document.addEventListener('input', function (e) { if (e.target.id === 'exTitle') readForm(); });
})(window.NR);

/* ======== 13-settings.js ======== */
/* settings.js — themes, reading preferences, performance (lite) mode, backup/restore, extra data-file loader */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, esc = u.esc, prefs = NR.prefs;
  var de = document.documentElement;

  NR.themes = [
    { id: 'auto',       name: 'Auto', desc: 'Follows the system dark / light setting' },
    { id: 'paper',      name: 'Paper', desc: 'Clean and light — for daytime' },
    { id: 'chai',       name: 'Sepia', desc: 'Warm old-paper tone — easy on the eyes for long reads' },
    { id: 'blackboard', name: 'Blackboard', desc: 'Green board with chalk tones' },
    { id: 'notebook',   name: 'Lab notebook', desc: 'Graph-paper grid, blue ink, red margin' },
    { id: 'midnight',   name: 'Midnight', desc: 'Deep blue dark mode' },
    { id: 'ember',      name: 'Amber night', desc: 'Very little blue light — for late-night study' },
    { id: 'contrast',   name: 'High contrast', desc: 'Black + yellow, bold lines — low vision / AMOLED saving' },
    { id: 'ink',        name: 'Ink', desc: 'Pure black and white — distraction-free, print-like' },
  ];

  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function resolve(id) { return id === 'auto' ? (mq && mq.matches ? 'midnight' : 'paper') : id; }

  function themeColor() {
    var m = $('meta[name="theme-color"]');
    if (m) m.setAttribute('content', getComputedStyle(de).getPropertyValue('--bg').trim() || '#f4f1ea');
  }
  function setTheme(id, animate) {
    var apply = function () {
      de.setAttribute('data-theme', resolve(id));
      prefs.set('theme', id);
      themeColor(); markTheme();
    };
    if (animate && document.startViewTransition && !de.classList.contains('lite')) document.startViewTransition(apply);
    else apply();
  }
  function markTheme() {
    u.$$('.th-card').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.id === prefs.get('theme'))); });
  }
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (prefs.get('theme') === 'auto') setTheme('auto'); });

  /* ---------- Reading prefs apply ---------- */
  function liteDefault() {
    var weak = (navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2);
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    return !!(weak || reduce);
  }
  function isLite() { var l = prefs.get('lite'); return l == null ? liteDefault() : !!l; }

  function apply() {
    de.style.setProperty('--fs', prefs.get('fs') + 'px');
    de.style.setProperty('--lh', prefs.get('lh'));
    de.style.setProperty('--font', prefs.get('font') === 'serif' ? 'var(--font-serif)' : 'var(--font-sans)');
    de.setAttribute('data-density', prefs.get('density'));
    de.setAttribute('data-bold', prefs.get('bstyle')); de.setAttribute('data-hl', prefs.get('hstyle')); de.setAttribute('data-bcol', prefs.get('bcol'));
    de.classList.toggle('lite', isLite());
    var l = $('#list');
    if (l) { l.classList.toggle('grid', prefs.get('view') === 'grid'); }
    var sl = $('#savedList');
    if (sl) sl.classList.toggle('grid', prefs.get('view') === 'grid');
    themeColor();
  }

  /* ---------- Settings modal ---------- */
  function render() {
    var cur = prefs.get('theme');
    var th = NR.themes.map(function (t) {
      return '<button class="th-card" data-act="set-theme" data-id="' + t.id + '" data-theme="' + (t.id === 'auto' ? 'paper' : t.id) + '" aria-pressed="' + (t.id === cur) + '" title="' + esc(t.desc) + '">' +
        '<span class="th-prev"><i></i><i></i><i></i><b></b></span><span class="th-n">' + esc(t.name) + '</span><span class="th-d">' + esc(t.desc) + '</span></button>';
    }).join('');
    function seg(pref, items) {
      return '<div class="seg" role="group">' + items.map(function (it) {
        return '<button class="segb' + (String(prefs.get(pref)) === String(it[0]) ? ' on' : '') + '" data-act="set-pref" data-p="' + pref + '" data-v="' + it[0] + '">' + it[1] + '</button>';
      }).join('') + '</div>';
    }
    var lite = isLite();
    $('#setBody').innerHTML =
      '<section><h4>Theme</h4><div class="th-grid">' + th + '</div></section>' +
      '<section><h4>Reading</h4>' +
      '<div class="row"><label for="rngFs">Font size <b id="vFs">' + prefs.get('fs') + 'px</b></label><input type="range" id="rngFs" data-pref="fs" min="14" max="26" step="1" value="' + prefs.get('fs') + '"></div>' +
      '<div class="row"><label for="rngLh">Line spacing <b id="vLh">' + prefs.get('lh') + '</b></label><input type="range" id="rngLh" data-pref="lh" min="1.4" max="2.2" step="0.05" value="' + prefs.get('lh') + '"></div>' +
      '<p class="prev" id="fontPrev">रसायन विज्ञान: <strong>जल</strong> का क्वथनांक 100°C होता है। H₂O</p>' +
      '<div class="row"><label>Font</label>' + seg('font', [['sans', 'Sans'], ['serif', 'Serif']]) + '</div>' +
      '<div class="row"><label>Density</label>' + seg('density', [['cozy', 'Comfortable'], ['compact', 'Compact']]) + '</div>' +
      '<div class="row"><label>Card layout</label>' + seg('view', [['grid', 'Grid'], ['list', 'List']]) + '</div>' +
      '<div class="row"><label>Cards start</label>' + seg('fold', [['false', 'Expanded'], ['true', 'Collapsed']]) + '</div>' +
      '<label class="sw"><input type="checkbox" id="swAuto" ' + (prefs.get('autoRead') ? 'checked' : '') + '><span class="sw-b"></span><span class="sw-t"><b>Auto-mark ✓ read when tapping “Next” in read mode</b><small>When off, read marks are only set by your own button taps.</small></span></label></section>' +
      '<section><h4>Text & highlight style</h4>' +
      '<div class="prev" id="stylePrev"><p>रसायन विज्ञान: <strong>जल</strong> का क्वथनांक <strong>100°C</strong> होता है, <em>समुद्र तल पर</em>।</p>' +
      '<ul class="pts prevl"><li class="hl1">Yellow highlight — <strong>key fact</strong></li><li class="hl2">Green highlight</li><li class="hl3">Pink highlight</li><li class="hl4">Blue highlight</li></ul></div>' +
      '<div class="row"><label>Bold word style</label>' + seg('bstyle', [['marker', 'Marker'], ['color', 'Coloured'], ['pill', 'Pill'], ['plain', 'Plain']]) + '</div>' +
      '<div class="row"><label>Bold colour</label><div class="swatches" role="group" aria-label="Bold colour">' +
      [['auto', 'Theme', ''], ['orange', 'Orange', '#ea580c'], ['green', 'Green', '#16a34a'], ['pink', 'Pink', '#db2777'], ['blue', 'Blue', '#2563eb'], ['purple', 'Purple', '#7c3aed'], ['gold', 'Gold', '#ca8a04']].map(function (c) {
        return '<button class="swatch' + (c[0] === 'auto' ? ' auto' : '') + (prefs.get('bcol') === c[0] ? ' on' : '') + '" style="--sw:' + (c[2] || 'transparent') + '" data-act="set-pref" data-p="bcol" data-v="' + c[0] + '" aria-label="' + c[1] + '" title="' + c[1] + '"></button>';
      }).join('') + '</div></div>' +
      '<div class="row"><label>Highlight look</label>' + seg('hstyle', [['soft', 'Soft'], ['mini', 'Light'], ['solid', 'Strong']]) + '</div></section>' +
      (NR.game ? NR.game.settingsHTML() : '') +
      '<section><h4>Performance</h4>' +
      '<label class="sw"><input type="checkbox" id="swLite" ' + (lite ? 'checked' : '') + '><span class="sw-b"></span><span class="sw-t"><b>Lite mode (for low-RAM / slow phones)</b><small>Fewer animations, loads in small batches. Turns on automatically on low RAM.</small></span></label></section>' +
      '<section><h4>Data & backup</h4><div class="btnrow">' +
      '<button class="btn" data-act="add-file">+ Add data file (.js)</button>' +
      '<button class="btn" data-act="backup">⬇ Back up highlights / saves / progress</button>' +
      '<button class="btn" data-act="restore">⬆ Restore backup</button>' +
      '<button class="btn danger" data-act="clear-marks">Delete all highlights / saves</button>' +
      '<button class="btn danger" data-act="clear-status">Reset study progress</button></div>' +
      '<p class="hint">' + (NR.store.persistent ? 'Your highlights, saves and study progress are stored on this device. Take a backup before clearing app data or uninstalling.' : '⚠ Storage is disabled — highlights and saves will be lost when you close the app.') +
      ' Only add data files you trust: <code>data_*.js</code>.</p></section>';
  }

  NR.act['open-settings'] = function () { render(); NR.modal.open('mSettings'); };
  NR.act['set-theme'] = function (b) { setTheme(b.dataset.id, true); };
  NR.act['set-pref'] = function (b) {
    var p = b.dataset.p, v = b.dataset.v;
    if (p === 'fold') v = v === 'true';
    prefs.set(p, v); apply();
    if (p === 'fold') u.$$('.card[data-t="c"]').forEach(function (c) { c.classList.toggle('folded', v); });
    if (p === 'view' || p === 'font' || p === 'density') {
      u.$$('[data-p="' + p + '"]', $('#setBody')).forEach(function (x) { x.classList.toggle('on', x.dataset.v === String(v)); });
    } else {
      u.$$('[data-p="' + p + '"]', $('#setBody')).forEach(function (x) { x.classList.toggle('on', x.dataset.v === String(v)); });
    }
  };
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (el.dataset && el.dataset.pref) {
      var v = +el.value; prefs.set(el.dataset.pref, v); apply();
      var lab = el.dataset.pref === 'fs' ? $('#vFs') : $('#vLh');
      if (lab) lab.textContent = el.dataset.pref === 'fs' ? v + 'px' : v;
    }
  });
  document.addEventListener('change', function (e) {
    if (e.target.id === 'swAuto') { prefs.set('autoRead', e.target.checked); return; }
    if (e.target.id === 'swLite') { prefs.set('lite', e.target.checked); apply(); u.toast(e.target.checked ? 'Lite mode on' : 'Lite mode off', 1400); }
  });

  /* ---------- Backup / restore / clear ---------- */
  NR.act['backup'] = function () {
    u.download('notes-reader-backup-' + new Date().toISOString().slice(0, 10) + '.json', NR.store.exportJSON());
    u.toast('Backup saved');
  };
  NR.act['restore'] = function () { $('#restorePick').click(); };
  $('#restorePick').addEventListener('change', function (e) {
    var f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    var r = new FileReader();
    r.onload = function () {
      try { var n = NR.store.importJSON(String(r.result)); u.toast(n + ' items restored'); }
      catch (err) { u.toast('This is not a valid backup file'); }
    };
    r.readAsText(f);
  });
  NR.act['clear-marks'] = function (b) {
    if (b.dataset.sure !== '1') {
      b.dataset.sure = '1'; b.textContent = 'Sure? Tap again';
      setTimeout(function () { b.dataset.sure = ''; b.textContent = 'Delete all highlights / saves'; }, 3000);
      return;
    }
    NR.store.clearAll(); u.toast('Everything deleted'); b.dataset.sure = ''; b.textContent = 'Delete all highlights / saves';
  };

  NR.act['clear-status'] = function (b) {
    if (b.dataset.sure !== '1') {
      b.dataset.sure = '1'; b.textContent = 'Sure? Tap again';
      setTimeout(function () { b.dataset.sure = ''; b.textContent = 'Reset study progress'; }, 3000);
      return;
    }
    NR.status.clear(); u.toast('Progress reset'); b.dataset.sure = ''; b.textContent = 'Reset study progress';
  };

  /* ---------- Extra data-file loader (page chalte-chalte .js file jodna) ---------- */
  NR.act['add-file'] = function () { $('#filePick').click(); };
  $('#filePick').addEventListener('change', async function (e) {
    var files = Array.prototype.slice.call(e.target.files); e.target.value = '';
    if (!files.length) return;
    var before = NR.model.notes.length;
    for (var i = 0; i < files.length; i++) {
      var text = await files[i].text();
      await new Promise(function (res) {
        var url = URL.createObjectURL(new Blob([text], { type: 'text/javascript' })), s = document.createElement('script');
        s.src = url; s.onload = s.onerror = function () { s.remove(); URL.revokeObjectURL(url); res(); };
        document.head.appendChild(s);
      });
    }
    var added = await NR.model.ingest();
    NR.app.dataChanged();
    u.toast(added ? added + ' new notes added' : 'No new notes found (maybe already added)');
    NR.modal.close('mSettings');
  });

  NR.settings = { apply: apply, setTheme: setTheme, markTheme: markTheme };
})(window.NR);

/* ======== 13b-game.js ======== */
/* game.js — XP, Level, Streak, Daily goal, बैज, Topic-ट्रॉफ़ी + जश्न (popup/confetti).
   Sab kuch aapke padhne ke kaam (पढ़ा / रिवाइज़ / स्टार / Highlight / Save) se apne-aap banta hai.
   XP ek note par ek hi baar milta hai (toggle karke XP farm nahi hota). */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, $$ = u.$$, esc = u.esc, C = NR.config, S = NR.status, store = NR.store, prefs = NR.prefs, M = NR.model;
  var KEY = C.storagePrefix + 'game';
  var XP = { r: 10, d: 15, s: 2, h: 3, v: 3, goal: 20, badge: 25, topicR: 30, topicD: 40 };
  var DAYN = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  var RANKS = [[1, 'Novice'], [3, 'Student'], [5, 'Learner'], [8, 'Seeker'], [12, 'Expert'], [16, 'Warrior'], [20, 'Champion'], [25, 'Guru'], [30, 'Master']];
  var G = null, ready = false, pv = {}, pm = {};

  /* ---------- state ---------- */
  function blank() {
    return { v: 1, xp: 0, lv: 1, best: 0, maxDay: 0, goalDays: 0, seeded: 0, days: {}, gd: {}, bd: {}, flags: {}, themes: {},
             aw: { r: {}, d: {}, s: {}, h: {}, v: {} }, today: { date: '', r: {}, d: {} } };
  }
  function fix(o) {
    var b = blank();
    if (!o || typeof o !== 'object') return b;
    Object.keys(b).forEach(function (k) { if (o[k] != null) b[k] = o[k]; });
    ['days', 'gd', 'bd', 'flags', 'themes'].forEach(function (k) { if (!b[k] || typeof b[k] !== 'object') b[k] = {}; });
    if (!b.aw || typeof b.aw !== 'object') b.aw = blank().aw;
    ['r', 'd', 's', 'h', 'v'].forEach(function (k) { if (!b.aw[k]) b.aw[k] = {}; });
    if (!b.today || typeof b.today !== 'object') b.today = { date: '', r: {}, d: {} };
    b.xp = +b.xp || 0; b.lv = +b.lv || 1;
    return b;
  }
  function load() { try { var v = localStorage.getItem(KEY); return v ? JSON.parse(v) : null; } catch (e) { return null; } }
  var save = u.debounce(function () { try { localStorage.setItem(KEY, JSON.stringify(G)); } catch (e) {} }, 400);
  window.addEventListener('pagehide', function () { if (G) { try { localStorage.setItem(KEY, JSON.stringify(G)); } catch (e) {} } });

  /* ---------- dates / streak ---------- */
  function p2(n) { return n < 10 ? '0' + n : '' + n; }
  function day(d) { d = d || new Date(); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
  function rollDay() {
    var t = day();
    if (G.today.date !== t) G.today = { date: t, r: {}, d: {} };
    var keys = Object.keys(G.days);
    if (keys.length > 420) { keys.sort(); keys.slice(0, keys.length - 400).forEach(function (k) { delete G.days[k]; delete G.gd[k]; }); }
  }
  function todayCount() { return G.days[day()] || 0; }
  function streak() {
    var d = new Date(), n = 0;
    if (!(G.days[day(d)] > 0)) d.setDate(d.getDate() - 1);
    while (G.days[day(d)] > 0 && n < 4000) { n++; d.setDate(d.getDate() - 1); }
    return n;
  }
  function goal() { return Math.max(1, Number(prefs.get('goal')) || 5); }

  /* ---------- level ---------- */
  function need(L) { return L <= 1 ? 0 : Math.round(40 * Math.pow(L - 1, 1.5)); }
  function lvInfo() {
    var L = 1; while (G.xp >= need(L + 1) && L < 99) L++;
    var a = need(L), b = need(L + 1);
    return { lv: L, a: a, b: b, pct: Math.max(0, Math.min(100, ((G.xp - a) / (b - a)) * 100)), left: b - G.xp };
  }
  function rankOf(L) { var r = RANKS[0][1]; RANKS.forEach(function (x) { if (L >= x[0]) r = x[1]; }); return r; }

  /* ---------- badges ---------- */
  function B(id, cat, icon, name, desc, tier, val, nd) { return { id: id, cat: cat, icon: icon, name: name, desc: desc, tier: tier, val: val, need: nd }; }
  var CAT = ['Reading', 'Revision', 'Streaks', 'Daily goal', 'Library & topics', 'Special'];
  var BADGES = [
    B('r1', CAT[0], '🌱', 'First Step', 'Read your first note', 1, function (c) { return c.read; }, 1),
    B('r10', CAT[0], '📖', 'Page Turner', 'Read 10 notes', 1, function (c) { return c.read; }, 10),
    B('r25', CAT[0], '🐛', 'Bookworm', 'Read 25 notes', 1, function (c) { return c.read; }, 25),
    B('r50', CAT[0], '🎯', 'Sharpshooter', 'Read 50 notes', 2, function (c) { return c.read; }, 50),
    B('r100', CAT[0], '💯', 'Centurion', 'Read 100 notes', 3, function (c) { return c.read; }, 100),
    B('r250', CAT[0], '🏹', 'Champion', 'Read 250 notes', 4, function (c) { return c.read; }, 250),
    B('r500', CAT[0], '🧠', 'Ocean of Knowledge', 'Read 500 notes', 5, function (c) { return c.read; }, 500),
    B('rall', CAT[0], '👑', 'Whole Ocean', 'Read every note', 5, function (c) { return c.read; }, function (c) { return c.total; }),
    B('d5', CAT[1], '🔁', 'Revision Begins', 'Revise 5 notes', 1, function (c) { return c.rev; }, 5),
    B('d25', CAT[1], '🛡️', 'Revision Ranger', 'Revise 25 notes', 2, function (c) { return c.rev; }, 25),
    B('d100', CAT[1], '🏆', 'Memory King', 'Revise 100 notes', 4, function (c) { return c.rev; }, 100),
    B('dall', CAT[1], '💎', 'Diamond Memory', 'Revise every note', 5, function (c) { return c.rev; }, function (c) { return c.total; }),
    B('s3', CAT[2], '🔥', 'On Fire', '3-day streak', 1, function (c) { return c.best; }, 3),
    B('s7', CAT[2], '⚡', 'Week Hero', '7-day streak', 2, function (c) { return c.best; }, 7),
    B('s14', CAT[2], '💪', 'Fortnight Fighter', '14-day streak', 3, function (c) { return c.best; }, 14),
    B('s30', CAT[2], '🚀', 'Month Master', '30-day streak', 4, function (c) { return c.best; }, 30),
    B('s100', CAT[2], '🌟', 'Hundred-Day Legend', '100-day streak', 5, function (c) { return c.best; }, 100),
    B('g1', CAT[3], '🎯', 'Goal Getter', 'Hit your daily goal for the first time', 1, function (c) { return c.goalDays; }, 1),
    B('g7', CAT[3], '🥇', 'Lucky Seven', 'Hit your goal on 7 days', 2, function (c) { return c.goalDays; }, 7),
    B('g30', CAT[3], '🏅', 'Goal Master', 'Hit your goal on 30 days', 4, function (c) { return c.goalDays; }, 30),
    B('day10', CAT[3], '🌪️', 'Stormy Day', 'Read 10 notes in a day', 2, function (c) { return c.maxDay; }, 10),
    B('day25', CAT[3], '🏃', 'Marathon Runner', 'Read 25 notes in a day', 3, function (c) { return c.maxDay; }, 25),
    B('hl10', CAT[4], '🖍️', 'Colourist', 'Make 10 highlights', 1, function (c) { return c.hl; }, 10),
    B('hl50', CAT[4], '🎨', 'Painter', 'Make 50 highlights', 3, function (c) { return c.hl; }, 50),
    B('sv10', CAT[4], '🔖', 'Collector', 'Save 10 items', 1, function (c) { return c.saved; }, 10),
    B('sv50', CAT[4], '📚', 'Library', 'Save 50 items', 3, function (c) { return c.saved; }, 50),
    B('st5', CAT[4], '⭐', 'Starry', 'Star 5 notes', 1, function (c) { return c.star; }, 5),
    B('st25', CAT[4], '🌠', 'Constellation', 'Star 25 notes', 3, function (c) { return c.star; }, 25),
    B('tp1', CAT[4], '🏅', 'Topic Conqueror', 'Finish any one topic', 1, function (c) { return c.topR; }, 1),
    B('tp3', CAT[4], '🧭', 'Explorer', 'Finish 3 topics', 2, function (c) { return c.topR; }, 3),
    B('tp5', CAT[4], '🗺️', 'Winner', 'Finish 5 topics', 3, function (c) { return c.topR; }, 5),
    B('tpd1', CAT[4], '🔮', 'Topic Master', 'Fully revise any topic', 3, function (c) { return c.topD; }, 1),
    B('early', CAT[5], '🌅', 'Early Bird', 'Read between 4–8 AM', 2, function (c) { return c.early; }, 1),
    B('owl', CAT[5], '🦉', 'Night Owl', 'Read after 10 PM', 2, function (c) { return c.owl; }, 1),
    B('style', CAT[5], '💅', 'Style Icon', 'Try 5 different themes', 2, function (c) { return c.themes; }, 5)
  ];
  function needOf(b, c) { return typeof b.need === 'function' ? Math.max(1, b.need(c)) : b.need; }

  function ctx() {
    var notes = M.notes, c = S.counts(notes), mc = store.counts(), by = {}, topR = 0, topD = 0;
    notes.forEach(function (n) {
      var e = by[n.tk] || (by[n.tk] = [0, 0, 0]), m = S.get(n.key);
      e[0]++; if (m && m.r) e[1]++; if (m && m.d) e[2]++;
    });
    Object.keys(by).forEach(function (k) { if (by[k][0] && by[k][1] === by[k][0]) topR++; if (by[k][0] && by[k][2] === by[k][0]) topD++; });
    return { read: c.read, rev: c.rev, star: c.star, total: c.n, hl: mc.hl, saved: mc.saved, best: G.best, goalDays: G.goalDays, maxDay: G.maxDay,
             topR: topR, topD: topD, early: G.flags.early ? 1 : 0, owl: G.flags.owl ? 1 : 0, themes: Object.keys(G.themes).length, by: by };
  }

  /* ---------- popups (queue) ---------- */
  var queue = [], busy = false, host;
  function fxOn() { return prefs.get('fx') !== false; }
  function gfx() {
    if (!host) { host = document.createElement('div'); host.className = 'gfx'; host.id = 'gfx'; host.setAttribute('aria-live', 'polite'); document.body.appendChild(host); }
    return host;
  }
  function push(it) { queue.push(it); pump(); }
  function pump() {
    if (busy || !queue.length) return;
    busy = true;
    var it = queue.shift();
    show(it, function () { busy = false; setTimeout(pump, 180); });
  }
  function show(it, done) {
    if (!fxOn()) {
      u.toast(it.type === 'lvl' ? '🎉 Level ' + it.lv + ' — ' + it.rank : it.icon + ' ' + it.title + (it.xp ? '  +' + it.xp + ' XP' : ''), 2400);
      setTimeout(done, 600); return;
    }
    if (it.type === 'lvl') { showLevel(it, done); return; }
    var el = document.createElement('div');
    el.className = 'ach'; el.setAttribute('role', 'status');
    el.innerHTML = '<span class="ach-i">' + it.icon + '</span><span class="ach-t"><small>' + esc(it.kind) + '</small><b>' + esc(it.title) + '</b><span>' + esc(it.sub || '') + '</span></span>' + (it.xp ? '<span class="ach-x">+' + it.xp + ' XP</span>' : '');
    gfx().appendChild(el);
    void el.offsetWidth; el.classList.add('on');
    var closed = false;
    function close() { if (closed) return; closed = true; el.classList.remove('on'); setTimeout(function () { el.remove(); done(); }, 420); }
    el.addEventListener('click', function () { if (NR.app && it.go) NR.app.show('game'); close(); });
    setTimeout(close, 3600);
    if (it.confetti) confetti(gfx(), 22);
  }
  function showLevel(it, done) {
    var el = document.createElement('div');
    el.className = 'lvl'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Level up');
    el.innerHTML = '<div class="lvl-c"><small>Level up! 🎉</small><div class="lvl-n">' + it.lv + '</div><h3>' + esc(it.rank) + '</h3><p>Well done! Keep going — the next level is even better 🚀</p><button type="button">Keep going!</button></div>';
    gfx().appendChild(el);
    confetti(el, 44);
    void el.offsetWidth; el.classList.add('on');
    var closed = false;
    function close() { if (closed) return; closed = true; el.classList.remove('on'); setTimeout(function () { el.remove(); done(); }, 320); }
    el.querySelector('button').addEventListener('click', close);
    el.addEventListener('click', function (e) { if (e.target === el) close(); });
    setTimeout(close, 9000);
  }
  function confetti(parent, n) {
    if (document.documentElement.classList.contains('lite')) return;
    var cols = ['#ffd45a', '#ff5fb0', '#6a5cff', '#19e6c0', '#ff7a45', '#4aa8ff', '#ffffff'], h = '';
    for (var i = 0; i < n; i++) {
      h += '<i style="--x:' + (Math.random() * 100).toFixed(1) + '%;--r:' + Math.round(Math.random() * 360) + 'deg;--dx:' + Math.round((Math.random() - .5) * 160) + 'px;--d:' + (1.8 + Math.random() * 1.6).toFixed(2) + 's;--w:' + (Math.random() * .5).toFixed(2) + 's;--c:' + cols[i % cols.length] + '"></i>';
    }
    var cf = document.createElement('div'); cf.className = 'cf'; cf.innerHTML = h; parent.appendChild(cf);
    setTimeout(function () { cf.remove(); }, 4200);
  }
  function xpFx(n) {
    if (!n || !fxOn()) return;
    var el = document.createElement('div'); el.className = 'xpfx'; el.textContent = '+' + n + ' XP';
    gfx().appendChild(el); setTimeout(function () { el.remove(); }, 1400);
  }

  /* ---------- core: XP / events ---------- */
  function topicStat(tk) {
    var n = 0, r = 0, d = 0;
    M.notes.forEach(function (x) { if (x.tk !== tk) return; n++; var m = S.get(x.key); if (m && m.r) r++; if (m && m.d) d++; });
    return { n: n, r: r, d: d };
  }
  function checkTopic(tk, silent) {
    var t = M.topics.get(tk); if (!t) return 0;
    var st = topicStat(tk), g = 0;
    if (st.n && st.r === st.n && !G.bd['t:' + tk + ':r']) {
      G.bd['t:' + tk + ':r'] = Date.now();
      if (!silent) { G.xp += XP.topicR; g += XP.topicR; push({ type: 'b', kind: 'Topic complete! 🏅', icon: '📘', title: t.name, sub: 'Fully read', xp: XP.topicR, go: 1, confetti: 1 }); }
    }
    if (st.n && st.d === st.n && !G.bd['t:' + tk + ':d']) {
      G.bd['t:' + tk + ':d'] = Date.now();
      if (!silent) { G.xp += XP.topicD; g += XP.topicD; push({ type: 'b', kind: 'Topic master! 🏆', icon: '🔮', title: t.name, sub: 'Fully revised', xp: XP.topicD, go: 1, confetti: 1 }); }
    }
    return g;
  }
  function checkBadges(silent) {
    var c = ctx(), g = 0;
    BADGES.forEach(function (b) {
      if (G.bd[b.id]) return;
      if (b.val(c) >= needOf(b, c)) {
        G.bd[b.id] = Date.now();
        if (!silent) { G.xp += XP.badge; g += XP.badge; push({ type: 'b', kind: 'New badge! 🎖️', icon: b.icon, title: b.name, sub: b.desc, xp: XP.badge, go: 1, confetti: b.tier >= 3 }); }
      }
    });
    return g;
  }
  function levelCheck(silent) {
    var L = lvInfo().lv;
    if (L > G.lv) { G.lv = L; if (!silent) push({ type: 'lvl', lv: L, rank: rankOf(L) }); }
    else if (L < G.lv) G.lv = L;
  }

  // ek (type,key) ka kaam: XP + roz ki ginti. type: r / d / s
  function act(type, key) {
    var gain = 0;
    if (!G.aw[type][key]) { G.aw[type][key] = 1; G.xp += XP[type]; gain += XP[type]; }
    if (type === 'r' || type === 'd') {
      var t = day(), td = G.today[type];
      if (!td[key]) {
        td[key] = 1; G.days[t] = (G.days[t] || 0) + 1;
        if (G.days[t] > G.maxDay) G.maxDay = G.days[t];
        var h = new Date().getHours();
        if (h >= 4 && h < 8) G.flags.early = 1;
        if (h >= 22 || h < 4) G.flags.owl = 1;
      }
    }
    return gain;
  }

  function onStatus(key) {
    if (!ready) return;
    if (key == null) { resync(); return; }
    rollDay();
    var n = M.byKey.get(key), m = S.get(key) || {};
    var now = (m.r ? 1 : 0) | (m.d ? 2 : 0) | (m.s ? 4 : 0), old = pv[key] | 0;
    pv[key] = now;
    if (now === old) return;
    var before = todayCount(), gain = 0, any = false;
    if ((now & 1) && !(old & 1)) { gain += act('r', key); any = true; }
    if ((now & 2) && !(old & 2)) { gain += act('d', key); any = true; }
    if ((now & 4) && !(old & 4)) { gain += act('s', key); }
    if (!any && !gain) return;
    if (any && n) gain += checkTopic(n.tk, false);
    finish(gain, before);
  }
  function onMark(id) {
    if (!ready) return;
    if (id == null) { resync(); return; }
    var m = store.get(id) || {}, now = (m.c ? 1 : 0) | (m.v ? 2 : 0), old = pm[id] | 0, gain = 0;
    pm[id] = now;
    if ((now & 1) && !(old & 1) && !G.aw.h[id]) { G.aw.h[id] = 1; G.xp += XP.h; gain += XP.h; }
    if ((now & 2) && !(old & 2) && !G.aw.v[id]) { G.aw.v[id] = 1; G.xp += XP.v; gain += XP.v; }
    if (gain) finish(gain, todayCount());
  }

  // har event ke baad: goal bonus, streak, badges, level, popups
  function finish(gain, beforeCount) {
    rollDay();
    var st = streak(); if (st > G.best) G.best = st;
    var t = day(), after = todayCount(), gl = goal();
    if (beforeCount < gl && after >= gl && !G.gd[t]) {
      G.gd[t] = 1; G.goalDays++; G.xp += XP.goal; gain += XP.goal;
      push({ type: 'b', kind: 'Daily goal done! 🎯', icon: '🎯', title: after + ' notes today', sub: 'Great — streak ' + st + ' days 🔥', xp: XP.goal, go: 1, confetti: 1 });
    }
    gain += checkBadges(false);
    levelCheck(false);
    xpFx(gain);
    save(); emit();
  }

  /* ---------- seed / resync (purani padhai ko bina shor ke ginna) ---------- */
  function seed(silent) {
    var added = 0;
    M.notes.forEach(function (n) {
      var m = S.get(n.key); if (!m) return;
      ['r', 'd', 's'].forEach(function (f) { if (m[f] && !G.aw[f][n.key]) { G.aw[f][n.key] = 1; G.xp += XP[f]; added += XP[f]; } });
    });
    store.marks.forEach(function (m, id) {
      if (m.c && !G.aw.h[id]) { G.aw.h[id] = 1; G.xp += XP.h; added += XP.h; }
      if (m.v && !G.aw.v[id]) { G.aw.v[id] = 1; G.xp += XP.v; added += XP.v; }
    });
    M.topics.forEach(function (t, tk) { checkTopic(tk, true); });
    checkBadges(true);
    levelCheck(true);
    return added;
  }
  function snapshot() {
    pv = {}; pm = {};
    M.notes.forEach(function (n) { var m = S.get(n.key); if (m) pv[n.key] = (m.r ? 1 : 0) | (m.d ? 2 : 0) | (m.s ? 4 : 0); });
    store.marks.forEach(function (m, id) { pm[id] = (m.c ? 1 : 0) | (m.v ? 2 : 0); });
  }
  function resync() { snapshot(); seed(true); save(); emit(); }

  /* ---------- UI: quest strip, pill ---------- */
  function questInner(big) {
    var L = lvInfo(), gl = goal(), tc = todayCount(), st = streak(), got = BADGES.filter(function (b) { return G.bd[b.id]; }).length;
    return '<div class="q-ring" style="--p:' + L.pct.toFixed(1) + '"><b>' + L.lv + '</b><small>Level</small></div>' +
      '<div class="q-mid"><div class="q-rank">' + esc(rankOf(L.lv)) + ' <em>· ' + u.fmt(G.xp) + ' XP</em></div>' +
      '<div class="q-bar"><i style="width:' + L.pct.toFixed(1) + '%"></i></div>' +
      '<div class="q-sub">Level ' + (L.lv + 1) + ' in ' + u.fmt(Math.max(0, L.left)) + ' XP to go' + (big ? ' · next rank: ' + esc(nextRank(L.lv)) : '') + '</div></div>' +
      '<div class="q-row"><span class="q-chip">🔥 ' + st + ' days</span>' +
      '<span class="q-chip' + (tc >= gl ? ' ok' : '') + '">🎯 ' + Math.min(tc, gl) + '/' + gl + ' today' + (tc >= gl ? ' ✓' : '') + '</span>' +
      '<span class="q-goal" aria-hidden="true"><i style="width:' + Math.min(100, (tc / gl) * 100).toFixed(0) + '%"></i></span>' +
      '<span class="q-chip">🏅 ' + got + '/' + BADGES.length + '</span></div>';
  }
  function nextRank(L) { for (var i = 0; i < RANKS.length; i++) if (RANKS[i][0] > L) return RANKS[i][1] + ' (level ' + RANKS[i][0] + ')'; return 'Top rank 👑'; }
  function renderQuest() {
    var q = $('#quest'); if (q) q.innerHTML = questInner(false);
    var p = $('#gpill');
    if (p) {
      var st = streak(), L = lvInfo().lv;
      p.innerHTML = '<span class="fl">🔥</span><b>' + st + '</b><i>Lv ' + L + '</i>';
      p.classList.toggle('hot', st > 0 && todayCount() > 0);
      p.setAttribute('aria-label', 'Streak ' + st + ' days, level ' + L);
    }
  }
  function emit() {
    renderQuest();
    if (document.documentElement.getAttribute('data-tab') === 'game') render();
  }

  /* ---------- UI: Achievements page ---------- */
  function weekHTML() {
    var h = '', t = day(), d = new Date();
    d.setDate(d.getDate() - 6);
    for (var i = 0; i < 7; i++) {
      var k = day(d), c = G.days[k] || 0, cls = 'g-day' + (G.gd[k] ? ' goal' : c ? ' on' : '') + (k === t ? ' today' : '');
      h += '<div class="' + cls + '"><s>' + (G.gd[k] ? '🎯' : c ? c : d.getDate()) + '</s>' + DAYN[d.getDay()] + '</div>';
      d.setDate(d.getDate() + 1);
    }
    return h;
  }
  function badgesHTML() {
    var c = ctx(), now = Date.now(), h = '', total = BADGES.length, got = 0;
    CAT.forEach(function (cat) {
      var list = BADGES.filter(function (b) { return b.cat === cat; }), g = 0, tiles = '';
      list.forEach(function (b) {
        var ts = G.bd[b.id], nd = needOf(b, c), v = Math.min(nd, b.val(c));
        if (ts) { g++; got++; }
        tiles += '<div class="bdg t' + b.tier + (ts ? ' got' + (now - ts < 172800000 ? ' new' : '') : ' lock-i') + '" title="' + esc(b.desc) + '"><span class="bdg-i">' + b.icon + '</span><b>' + esc(b.name) + '</b><small>' + esc(b.desc) + '</small>' +
          (ts ? '' : '<span class="bdg-p"><i style="width:' + Math.round((v / nd) * 100) + '%"></i></span><span class="bdg-n">' + v + ' / ' + nd + '</span>') + '</div>';
      });
      h += '<section class="g-sec"><h3>' + cat + ' <small>' + g + '/' + list.length + '</small></h3><div class="bdg-grid">' + tiles + '</div></section>';
    });
    return { html: h, got: got, total: total };
  }
  function trophiesHTML() {
    var h = '', c = ctx(), any = false;
    Array.from(M.topics.values()).sort(function (a, b) { return a.order - b.order; }).forEach(function (t) {
      var e = c.by[t.key]; if (!e) return; any = true;
      var r = !!G.bd['t:' + t.key + ':r'], d = !!G.bd['t:' + t.key + ':d'];
      h += '<button type="button" class="tro' + (d ? ' d' : r ? ' r' : '') + '" data-act="st-topic" data-v="' + esc(t.key) + '"><span class="tro-i">' + (d ? '🏆' : r ? '✅' : '📘') + '</span>' +
        '<span><b>' + esc(t.name) + '</b><br><small>Read ' + e[1] + '/' + e[0] + ' · Revised ' + e[2] + '/' + e[0] + '</small></span><span class="tro-m">' + Math.round((e[1] / e[0]) * 100) + '%</span>' +
        '<span class="tro-bars"><i><s style="width:' + (e[1] / e[0] * 100).toFixed(0) + '%"></s></i><i><s style="width:' + (e[2] / e[0] * 100).toFixed(0) + '%"></s></i></span></button>';
    });
    return any ? h : '<p>Topic trophies will appear here once data is added.</p>';
  }
  function render() {
    var el = $('#gameBody'); if (!el || !G) return;
    rollDay();
    var c = ctx(), bd = badgesHTML(), gl = goal();
    var goals = [3, 5, 10, 15, 25].map(function (x) { return '<button class="segb' + (gl === x ? ' on' : '') + '" data-act="set-goal" data-v="' + x + '">' + x + '</button>'; }).join('');
    el.innerHTML =
      '<div class="quest big">' + questInner(true) + '</div>' +
      '<section class="g-sec"><h3>This week <small>Streak: ' + streak() + ' days · longest: ' + Math.max(G.best, streak()) + '</small></h3><p>Read or revise at least 1 note every day to keep your streak. 🎯 = goal met that day.</p>' +
      '<div class="g-week">' + weekHTML() + '</div>' +
      '<div class="g-goalrow"><span>Daily goal (notes)</span><div class="seg" role="group" aria-label="Daily goal">' + goals + '</div></div></section>' +
      '<section class="g-sec"><h3>Your report card</h3><div class="g-stats">' +
      '<div class="g-st"><b>' + u.fmt(G.xp) + '</b><small>Total XP</small></div><div class="g-st"><b>' + c.read + '/' + c.total + '</b><small>Notes read</small></div>' +
      '<div class="g-st"><b>' + c.rev + '</b><small>Revised</small></div><div class="g-st"><b>' + G.goalDays + '</b><small>Goal days</small></div></div>' +
      '<div class="g-prog"><i style="width:' + (c.total ? (c.read / c.total * 100).toFixed(1) : 0) + '%"></i></div><small style="color:var(--ink2)">Syllabus covered: ' + (c.total ? Math.round(c.read / c.total * 100) : 0) + '%</small></section>' +
      '<section class="g-sec"><h3>🏅 Badges <small>' + bd.got + '/' + bd.total + ' earned</small></h3><div class="g-prog"><i style="width:' + (bd.got / bd.total * 100).toFixed(0) + '%"></i></div></section>' +
      bd.html +
      '<section class="g-sec"><h3>Topic trophies <small>✅ Fully read · 🏆 Fully revised</small></h3><p>Tap a topic to open its notes.</p><div class="trophies">' + trophiesHTML() + '</div></section>';
  }

  /* ---------- actions ---------- */
  NR.act['set-goal'] = function (b) { prefs.set('goal', +b.dataset.v); u.toast('Daily goal: ' + b.dataset.v + ' notes 🎯', 1400); render(); renderQuest(); };
  NR.act['clear-game'] = function (b) {
    var lab = 'Reset XP / badges';
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = 'Sure? Tap again'; setTimeout(function () { b.dataset.sure = ''; b.textContent = lab; }, 3000); return; }
    G = blank(); G.seeded = 1; G.themes[document.documentElement.getAttribute('data-theme')] = 1;
    save(); snapshot(); emit(); b.dataset.sure = ''; b.textContent = lab; u.toast('XP and badges reset');
  };
  document.addEventListener('change', function (e) { if (e.target.id === 'swFx') prefs.set('fx', e.target.checked); });
  document.addEventListener('keydown', function (e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.id === 'quest') { e.preventDefault(); e.target.click(); }
  });
  prefs.on(function (k, v) {
    if (!ready) return;
    if (k === 'theme') { G.themes[v] = 1; var g = checkBadges(false); levelCheck(false); xpFx(g); save(); emit(); }
    else if (k === 'goal') { renderQuest(); }
  });

  /* ---------- public API ---------- */
  function settingsHTML() {
    var gl = String(goal());
    var seg = [3, 5, 10, 15, 25].map(function (x) { return '<button class="segb' + (gl === String(x) ? ' on' : '') + '" data-act="set-pref" data-p="goal" data-v="' + x + '">' + x + '</button>'; }).join('');
    return '<section><h4>Rewards 🎮</h4>' +
      '<div class="row"><label>Daily goal (notes)</label><div class="seg" role="group">' + seg + '</div></div>' +
      '<label class="sw"><input type="checkbox" id="swFx" ' + (fxOn() ? 'checked' : '') + '><span class="sw-b"></span><span class="sw-t"><b>Celebrations: popups, XP and confetti</b><small>When off, only a small message shows; XP and badges still accumulate.</small></span></label>' +
      '<div class="btnrow"><button class="btn danger" data-act="clear-game">Reset XP / badges</button></div></section>';
  }
  function init() {
    G = fix(load()); rollDay();
    G.themes[document.documentElement.getAttribute('data-theme') || 'paper'] = 1;
    var first = !G.seeded;
    snapshot();
    var added = seed(true);
    G.seeded = 1;
    var st = streak(); if (st > G.best) G.best = st;
    save(); ready = true; renderQuest();
    if (first && G.xp > 0) setTimeout(function () { u.toast('🎮 Your reading so far earned ' + u.fmt(G.xp) + ' XP — level ' + lvInfo().lv + ' (' + rankOf(lvInfo().lv) + ')', 3600); }, 900);
    S.on(onStatus); store.on(onMark);
    return added;
  }
  NR.game = {
    init: init, render: render, refresh: function () { if (ready) resync(); }, settingsHTML: settingsHTML,
    dump: function () { return G; },
    load: function (o) { G = fix(o); G.seeded = 1; if (ready) { snapshot(); seed(true); save(); emit(); } },
    badges: BADGES
  };
})(window.NR);

/* ======== 14-app.js ======== */
/* app.js — boot, tabs, filters, sorting, list rendering */
window.NR = window.NR || {};
(function (NR) {
  'use strict';
  var u = NR.u, $ = u.$, $$ = u.$$, esc = u.esc, cards = NR.cards, C = NR.config, store = NR.store, prefs = NR.prefs, Q = NR.query;

  var list, cur = { list: [], group: false, terms: [], re: null }, tab = 'notes', ready = false;
  var TABS = ['notes', 'saved', 'stats', 'game'];

  /* ---------- notes list ---------- */
  function runQuery(keepScroll) {
    cur = Q.run();
    var rows = [], n = cur.list, i;
    if (cur.group) {
      var last = null, g = null;
      for (i = 0; i < n.length; i++) {
        if (n[i].tk !== last) { g = { h: n[i].topic, n: 0 }; rows.push(g); last = n[i].tk; }
        g.n++; rows.push({ n: n[i] });
      }
    } else {
      for (i = 0; i < n.length; i++) rows.push({ n: n[i] });
    }
    var folded = !!prefs.get('fold'), re = cur.re;
    list.set(rows, function (r, k) {
      return r.h != null ? cards.group(r.h, r.n, 'notes', true) : cards.note(r.n, { i: k, folded: folded, re: re });
    });
    var total = NR.model.notes.length;
    $('#count').innerHTML = '<b>' + u.fmt(n.length) + '</b> notes' + (n.length !== total ? ' <span>/ ' + u.fmt(total) + '</span>' : '');
    renderStatusBar(); updateFab();
    var empty = $('#empty');
    empty.hidden = n.length > 0;
    if (!n.length) empty.innerHTML = total
      ? '<h3>No notes found</h3><p>Try a different search or filter.</p><button class="btn" data-act="reset-filters">Clear filters</button>'
      : noData();
    renderActive();
    syncFilterUI();
    if (!keepScroll && tab === 'notes' && window.scrollY > 200) window.scrollTo(0, 0);
    if (tab === 'stats') NR.stats.render();
  }
  function noData() {
    return '<h3>No data found</h3><p>Add your notes data file from <b>Settings → “Add data file”</b>.</p>' +
      '<button class="btn" data-act="add-file">+ Add data file</button>';
  }

  /* ---------- status chips (अपठित / रिवाइज़ बाकी / रिवाइज़्ड / स्टार) ---------- */
  var ST_CHIPS = [['', 'All'], ['unread', 'Unread'], ['todo', 'To revise'], ['rev', 'Revised'], ['star', '★ Important']];
  function renderStatusBar() {
    var c = NR.status.counts(NR.model.notes), v = { '': c.n, unread: c.unread, todo: c.todo, rev: c.rev, star: c.star };
    $('#statusBar').innerHTML = ST_CHIPS.map(function (x) {
      return '<button class="fchip' + (Q.F.status === x[0] ? ' on' : '') + '" data-act="st-filter" data-v="' + x[0] + '">' + x[1] + ' <small>' + v[x[0]] + '</small></button>';
    }).join('');
  }
  NR.act['st-filter'] = function (b) { Q.F.status = Q.F.status === b.dataset.v ? '' : b.dataset.v; runQuery(true); };

  /* sidebar topic: padhe hue / kul */
  var tpT;
  function updateTopicProgress() {
    clearTimeout(tpT);
    tpT = setTimeout(function () {
      var by = new Map();
      NR.model.notes.forEach(function (n) {
        var e = by.get(n.tk); if (!e) { e = [0, 0]; by.set(n.tk, e); }
        e[1]++; if (NR.status.flag(n.key, 'r')) e[0]++;
      });
      $$('.tp').forEach(function (b) {
        var e = by.get(b.dataset.v); if (!e) return;
        var c = b.querySelector('.tp-c'); if (c) c.textContent = e[0] + '/' + e[1];
        b.classList.toggle('done', e[0] === e[1] && e[1] > 0);
      });
    }, 120);
  }

  /* ---------- FAB (Read mode) ---------- */
  function updateFab() {
    var f = $('#fabRead'); if (!f) return;
    var list = cur.list, any = false;
    for (var i = 0; i < list.length; i++) if (NR.status.flag(list[i].key, 'r')) { any = true; break; }
    $('#fabTxt').textContent = any ? 'Continue' : 'Read';
    f.hidden = !list.length;
  }

  /* ---------- sidebar / filters ---------- */
  function tagLabel(t) { return (C.tagLabels[t] && C.tagLabels[t].label) || t; }
  function buildSidebar() {
    var M = NR.model, h;
    // subjects
    var sb = $('#fSubj');
    sb.hidden = M.subjects.size < 2;
    $('.chips', sb).innerHTML = Array.from(M.subjects.entries()).map(function (e) {
      return '<button class="chip btn-chip" data-act="f-subj" data-v="' + esc(e[0]) + '">' + esc(e[0]) + ' <small>' + e[1] + '</small></button>';
    }).join('');
    // tags
    var tags = Array.from(M.tags.entries()).sort(function (a, b) {
      var x = C.tagOrder.indexOf(a[0]), y = C.tagOrder.indexOf(b[0]);
      return (x < 0 ? 99 : x) - (y < 0 ? 99 : y);
    });
    $('#fTags').innerHTML = tags.map(function (e) {
      var d = C.tagLabels[e[0]] || { cls: 't-x' };
      return '<button class="chip btn-chip tag ' + d.cls + '" data-act="f-tag" data-v="' + esc(e[0]) + '">' + esc(tagLabel(e[0])) + ' <small>' + e[1] + '</small></button>';
    }).join('');
    // topics
    var multi = M.subjects.size > 1, lastS = null; h = '';
    var topics = Array.from(M.topics.values()).sort(function (a, b) { return a.order - b.order; });
    var maxC = Math.max.apply(null, topics.map(function (t) { return t.count; }).concat([1]));
    topics.forEach(function (t) {
      if (multi && t.subj !== lastS) { h += '<li class="tsub">' + esc(t.subj) + '</li>'; lastS = t.subj; }
      h += '<li><button class="tp" data-act="f-topic" data-v="' + esc(t.key) + '" style="--h:' + u.hue(t.name) + ';--w:' + (t.count / maxC).toFixed(2) + '">' +
        '<span class="tp-n">' + esc(t.name) + '</span><span class="tp-c">0/' + t.count + '</span></button></li>';
    });
    $('#fTopics').innerHTML = h;
    // sort select
    $('#sortSel').innerHTML = Object.keys(Q.SORTS).map(function (k) {
      return '<option value="' + k + '">' + Q.SORTS[k].label + '</option>';
    }).join('');
    $('#sortSel').value = prefs.get('sort');
    syncDir(); updateTopicProgress();
  }
  function syncFilterUI() {
    var F = Q.F;
    $$('[data-act="f-tag"]').forEach(function (b) { b.classList.toggle('on', F.tags.has(b.dataset.v)); });
    $$('[data-act="f-subj"]').forEach(function (b) { b.classList.toggle('on', F.subj.has(b.dataset.v)); });
    $$('[data-act="f-topic"]').forEach(function (b) { b.classList.toggle('on', F.topics.has(b.dataset.v)); });
    var any = Q.isFiltered();
    $('#btnReset').hidden = !any;
    $$('#q, #qm').forEach(function (i) { if (i.value !== F.q) i.value = F.q; });
  }
  function renderActive() {
    var F = Q.F, h = '';
    F.subj.forEach(function (v) { h += '<button class="chip x" data-act="f-subj" data-v="' + esc(v) + '">' + esc(v) + ' ✕</button>'; });
    F.tags.forEach(function (v) { h += '<button class="chip x" data-act="f-tag" data-v="' + esc(v) + '">' + esc(tagLabel(v)) + ' ✕</button>'; });
    F.topics.forEach(function (v) { var t = NR.model.topics.get(v); h += '<button class="chip x" data-act="f-topic" data-v="' + esc(v) + '">' + esc(t ? t.name : v) + ' ✕</button>'; });
    if (F.q) h += '<button class="chip x" data-act="f-q">“' + esc(F.q) + '” ✕</button>';
    if (F.status) { var sl = ST_CHIPS.filter(function (x) { return x[0] === F.status; })[0]; h += '<button class="chip x" data-act="st-filter" data-v="' + F.status + '">' + esc(sl ? sl[1] : F.status) + ' ✕</button>'; }
    $('#active').innerHTML = h; $('#active').hidden = !h;
  }
  function syncDir() {
    var d = prefs.get('dir') === 'desc';
    var b = $('#dirBtn');
    b.classList.toggle('desc', d);
    b.setAttribute('aria-label', d ? 'Sort: descending' : 'Sort: ascending');
    b.title = d ? 'Descending — tap to change' : 'Ascending — tap to change';
    $$('[data-act="view-grid"]').forEach(function (x) { x.classList.toggle('on', prefs.get('view') === 'grid'); });
    $$('[data-act="view-list"]').forEach(function (x) { x.classList.toggle('on', prefs.get('view') !== 'grid'); });
  }
  function toggleIn(set, v) { if (set.has(v)) set.delete(v); else set.add(v); }

  NR.act['f-tag'] = function (b) { toggleIn(Q.F.tags, b.dataset.v); runQuery(); };
  NR.act['f-subj'] = function (b) { toggleIn(Q.F.subj, b.dataset.v); runQuery(); };
  NR.act['f-topic'] = function (b) { toggleIn(Q.F.topics, b.dataset.v); runQuery(); closeDrawer(); if (tab !== 'notes') show('notes'); };
  NR.act['f-q'] = function () { Q.F.q = ''; runQuery(); };
  NR.act['clear-topics'] = function () { Q.F.topics.clear(); runQuery(); };
  NR.act['reset-filters'] = function () { Q.reset(); runQuery(); };
  NR.act['toggle-dir'] = function () { prefs.set('dir', prefs.get('dir') === 'desc' ? 'asc' : 'desc'); syncDir(); runQuery(true); };
  NR.act['view-grid'] = function () { prefs.set('view', 'grid'); NR.settings.apply(); syncDir(); };
  NR.act['view-list'] = function () { prefs.set('view', 'list'); NR.settings.apply(); syncDir(); };
  NR.act['fold-all'] = function () { setFold(true); };
  NR.act['unfold-all'] = function () { setFold(false); };
  function setFold(v) {
    prefs.set('fold', v);
    $$('.card[data-t="c"]').forEach(function (c) { c.classList.toggle('folded', v); });
    NR.actions.hide();
  }
  document.addEventListener('change', function (e) {
    if (e.target.id === 'sortSel') {
      prefs.set('sort', e.target.value);
      prefs.set('dir', Q.SORTS[e.target.value].def);
      syncDir(); runQuery();
    }
  });
  var onSearch = u.debounce(function (v) { Q.F.q = v.trim(); runQuery(); }, 170);
  $$('#q, #qm').forEach(function (inp) {
    inp.addEventListener('input', function (e) { onSearch(e.target.value); if (tab !== 'notes') show('notes'); });
  });

  /* ---------- drawer (mobile filters) ---------- */
  function closeDrawer() { document.documentElement.classList.remove('drawer'); }
  NR.act['open-filters'] = function () { document.documentElement.classList.add('drawer'); };
  NR.act['close-filters'] = closeDrawer;

  /* ---------- tabs ---------- */
  function show(t, noHash) {
    if (TABS.indexOf(t) < 0) t = 'notes';
    var changed = t !== tab;
    tab = t;
    NR.actions.hide();
    TABS.forEach(function (k) {
      var v = $('#v-' + k), on = k === t;
      if (on && v.hidden) v.hidden = false;
      v.classList.toggle('on', on);
      v.hidden = !on;
    });
    $$('[data-tab]').forEach(function (a) { a.classList.toggle('on', a.dataset.tab === t); a.setAttribute('aria-current', a.dataset.tab === t ? 'page' : 'false'); });
    document.documentElement.setAttribute('data-tab', t);
    document.documentElement.classList.remove('tb-hide');
    if (t === 'saved' && (NR.saved.dirty || changed)) NR.saved.render();
    if (t === 'stats') NR.stats.render();
    if (t === 'game') NR.game.render();
    if (changed) window.scrollTo(0, 0);
    if (!noHash) { try { history.replaceState(null, '', '#' + t); } catch (e) {} }
    NR.sel.setMode(NR.sel.on);
  }
  NR.act['tab'] = function (b) { show(b.dataset.v || b.dataset.tab); };

  /* ---------- go to a note ---------- */
  function goto(key, idx) {
    var n = NR.model.byKey.get(key);
    if (!n) return;
    show('notes');
    if (cur.list.indexOf(n) < 0) { Q.reset(); runQuery(true); }
    list.reveal(function (r) { return r.n && r.n.key === key; });
    requestAnimationFrame(function () {
      var card = $('.card[data-k="' + u.cssEsc(key) + '"]', $('#list'));
      if (!card) return;
      card.classList.remove('folded');
      var el = idx >= 0 ? card.querySelector('li[data-i="' + idx + '"]') : null;
      (el || card).scrollIntoView({ block: 'center', behavior: document.documentElement.classList.contains('lite') ? 'auto' : 'smooth' });
      var f = el || card;
      f.classList.remove('flash'); void f.offsetWidth; f.classList.add('flash');
    });
  }
  NR.act['goto'] = function (b) { goto(b.dataset.k, b.dataset.i != null ? +b.dataset.i : -1); };

  /* ---------- badge + selection bar ---------- */
  function updateBadge() {
    var c = store.counts().total, els = $$('.badge-saved');
    els.forEach(function (b) {
      b.textContent = c; b.hidden = !c;
      b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump');
    });
  }
  function updateSelBar() {
    var bar = $('#selbar'), on = NR.sel.on;
    bar.classList.toggle('on', on);
    $('#selN').textContent = NR.sel.size;
  }
  NR.sel.onChange(updateSelBar);

  /* ---------- public API ---------- */
  NR.app = {
    currentList: function () { return cur.list; },
    visibleIds: function () {
      if (tab === 'saved') return NR.saved.entries().map(function (e) { return e.id; });
      if (tab === 'notes') return cur.list.map(function (n) { return store.cid(n.key); });
      return [];
    },
    updateBadge: updateBadge,
    statusChanged: function () { renderStatusBar(); updateTopicProgress(); updateFab(); if (tab === 'stats') NR.stats.render(); },
    openTopic: function (tk) { Q.reset(); Q.F.topics.add(tk); show('notes'); runQuery(); },
    searchFor: function (term) { Q.reset(); Q.F.q = term; show('notes'); runQuery(); },
    refreshViews: function () { runQuery(true); NR.saved.markDirty(); if (tab === 'saved') NR.saved.render(); updateBadge(); },
    dataChanged: function () {
      NR.stats.invalidate(); buildSidebar(); brand(); runQuery(true); NR.saved.markDirty(); updateTopicProgress(); if (NR.game) NR.game.refresh();
      if (tab === 'saved') NR.saved.render();
    },
    show: show, goto: goto
  };

  function brand() {
    var M = NR.model, subj = Array.from(M.subjects.keys()).join(' · ');
    $('#brandSub').textContent = subj ? subj + ' · ' + u.fmt(M.notes.length) + ' Notes' : 'Add data';
    if (subj) document.title = C.appTitle + ' — ' + subj;
  }

  /* ---------- keyboard ---------- */
  document.addEventListener('keydown', function (e) {
    var t = e.target, typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT');
    if (NR.reader.on) return;
    if (e.key === '/' && !typing && !e.ctrlKey && !e.metaKey) { e.preventDefault(); $('#q').focus(); show('notes'); return; }
    if (e.key === 'Escape') {
      if (NR.reader.on) { NR.reader.close(); return; }
      if (NR.modal.closeTop()) return;
      if (document.documentElement.classList.contains('drawer')) { closeDrawer(); return; }
      if (typing && (t.id === 'q' || t.id === 'qm')) { t.blur(); return; }
      NR.actions.hide();
      if (NR.sel.on) NR.sel.setMode(false);
    }
  });
  window.addEventListener('hashchange', function () { var h = location.hash.slice(1); if (TABS.indexOf(h) >= 0 && h !== tab) show(h, true); });

  /* ---------- scroll: topbar chhupana (mobile) + FAB chhota ---------- */
  (function () {
    var last = 0, tick = false, de = document.documentElement;
    window.addEventListener('scroll', function () {
      if (tick) return; tick = true;
      requestAnimationFrame(function () {
        var y = window.scrollY, d = y - last;
        if (Math.abs(d) > 8) {
          de.classList.toggle('tb-hide', d > 0 && y > 120);
          de.classList.toggle('fab-s', d > 0 && y > 120);
          last = y;
        }
        if (y < 60) { de.classList.remove('tb-hide', 'fab-s'); }
        tick = false;
      });
    }, { passive: true });
  })();

  /* ---------- boot ---------- */
  async function boot() {
    NR.settings.apply();
    NR.settings.markTheme();
    var bar = $('#bootBar'), msg = $('#bootMsg');
    list = new NR.IncList($('#list'), $('#sentinel'));
    NR.saved.init(); NR.reader.init();
    var t0 = performance.now();
    await NR.model.ingest(null, function (i, n) {
      bar.style.transform = 'scaleX(' + (i / n) + ')';
      msg.textContent = 'Preparing notes… ' + Math.round((i / n) * 100) + '%';
    });
    buildSidebar(); brand();
    try { NR.game.init(); } catch (err) { console.error('game', err); }
    var h = location.hash.slice(1);
    runQuery(true);
    updateBadge();
    show(TABS.indexOf(h) >= 0 ? h : 'notes', true);
    var boot = $('#boot');
    boot.classList.add('done');
    setTimeout(function () { boot.remove(); }, 400);
    ready = true;
    NR.bootMs = Math.round(performance.now() - t0);
    document.documentElement.setAttribute('data-ready', '1');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(window.NR);
