Reader Pro (नोट्स रीडर) - Android project
Build: gradle assembleDebug  ->  app/build/outputs/apk/debug/app-debug.apk
Web files: app/src/main/assets/www/
